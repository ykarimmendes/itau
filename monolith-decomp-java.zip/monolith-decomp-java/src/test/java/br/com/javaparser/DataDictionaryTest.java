package br.com.javaparser;

import br.com.javaparser.methodparser.strategy.FilterContext;
import br.com.javaparser.methodparser.strategy.FilterStrategy;
import br.com.javaparser.methodparser.strategy.impl.ClassAndMethodFilterStrategy;
import br.com.javaparser.methodparser.strategy.impl.ClassEndsWithFilterStrategy;
import br.com.javaparser.parser.run.RunDataDictionary;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static java.util.Arrays.asList;

public class DataDictionaryTest {
    public static void main(String[] args) throws Exception {
        Path path = Paths.get("C:\\Backup\\Capco\\Projects\\Architecture\\PoC\\javaparser\\magia\\callgraph\\output\\nextbank-27.0.0-rc.1-DEV-SNAPSHOT-analysis.txt");

        Map<String, Set<String>> classMethods = new HashMap<>();
        classMethods.put("br.com.bradesco.next.platform.payment.VehicleDebtsPaymentController",
                new HashSet<>(asList("vehicleDebtsPending(br.com.bradesco.next.platform.payment.VehicleDebtsPaymentRequest,java.lang.String,java.lang.Long,java.lang.Integer,java.lang.Integer,java.lang.Long,java.lang.Long,java.lang.String)")));
        FilterStrategy classStrategy = new ClassAndMethodFilterStrategy(asList(classMethods));

        classStrategy = new ClassEndsWithFilterStrategy("Controller");
        FilterContext filterContext = new FilterContext(classStrategy);
        new RunDataDictionary().run(path, filterContext);
    }
}
