package br.com.javaparser;

import java.util.HashSet;
import java.util.Set;

public class RandomGen {

    public static void testRandom(Set<String> strings, long numAttempts) {
        long startInstant = System.nanoTime();
        long startCurrent;
        long currentDiff = 0;
        long totalConflict = 0;
        long avg = 0;
        for(int i=1; i<=numAttempts; i++) {
            startCurrent = System.nanoTime();
            String s = new RandomString(50).nextString();
            //System.out.println(s);
            currentDiff += System.nanoTime() - startCurrent;
            avg = currentDiff / i;
            if(!strings.contains(s)) {
                strings.add(s);
            } else {
                ++totalConflict;
                //System.out.println("Conflict[" + i + "]: [" + s + "]");
            }
        }

        System.out.println("Generated: [" + numAttempts + "][" + strings.size() + "][" + totalConflict + "] - All in [" + (System.nanoTime() - startInstant)/1000_000_000L + "] secs - Avg: [" +  avg + "] nanos");
    }

    public static void main(String[] args) {
        Set<String> strings = new HashSet<>();
        testRandom(strings, 10_000_000);
        testRandom(strings, 10_000_000);
        testRandom(strings, 10_000_000);
    }
}
