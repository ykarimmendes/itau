package br.com.javaparser;

import java.util.Locale;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ThreadLocalRandom;

import static java.util.Objects.requireNonNull;

public class RandomString {

    private static final Set<String> strings = ConcurrentHashMap.newKeySet();

    private static final String UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String LOWER = UPPER.toLowerCase(Locale.ROOT);
    private static final String DIGITS = "0123456789";
    private static final String SPECIAL = "!@#$%^&*";

    private static final String ALPLHNUM = UPPER + LOWER + DIGITS;
    private static final String ALL_SYMBOLS = ALPLHNUM + SPECIAL;

    private final Random random;
    private final char[] symbols;
    private final int length;

    public String nextString() {
        final char[] buf = new char[length];
        for (int idx = 0; idx < buf.length; ++idx) {
            buf[idx] = symbols[random.nextInt(symbols.length)];
        }
        return new String(buf);
    }

    private RandomString(int length, Random random, String symbols) {
        if (length < 1) throw new IllegalArgumentException();
        if (symbols.length() < 2) throw new IllegalArgumentException();
        this.random = requireNonNull(random);
        this.symbols = symbols.toCharArray();
        this.length = length;
    }

    public RandomString(int length) {
        this(length, ThreadLocalRandom.current(), ALL_SYMBOLS);
    }
}