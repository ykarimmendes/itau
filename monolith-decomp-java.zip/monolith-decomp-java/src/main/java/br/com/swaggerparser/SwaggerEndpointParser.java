package br.com.swaggerparser;

import io.swagger.models.HttpMethod;
import io.swagger.models.Model;
import io.swagger.models.Operation;
import io.swagger.models.RefModel;
import io.swagger.models.Swagger;
import io.swagger.models.parameters.BodyParameter;
import io.swagger.models.properties.ArrayProperty;
import io.swagger.models.properties.IntegerProperty;
import io.swagger.models.properties.LongProperty;
import io.swagger.models.properties.Property;
import io.swagger.models.properties.RefProperty;
import io.swagger.models.properties.StringProperty;
import io.swagger.parser.SwaggerParser;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

import static java.util.Collections.emptyList;
import static java.util.Objects.isNull;
import static java.util.Objects.requireNonNull;
import static java.util.Optional.empty;
import static java.util.Optional.ofNullable;
import static java.util.stream.Collectors.toList;

public class SwaggerEndpointParser {
    private String swaggerFile;
    private Swagger swagger;

    public SwaggerEndpointParser(String swaggerFile) {
        requireNonNull(swaggerFile);
        this.swaggerFile = swaggerFile;
    }

    public Optional<SwaggerEndpointData> getSwaggerPropertyInfo(String httpMethod, String endpoint, String propertyName) {
        Optional<HttpMethod> requiredHttpMethodOpt = parseHttpMethod(httpMethod);
        if(!requiredHttpMethodOpt.isPresent()) {
            System.err.println("Cannot find required http method: [" + httpMethod + "] for: [" + endpoint + "] [" + propertyName + "]");
            return empty();
        }

        loadSwagger();
        Optional<Map.Entry<HttpMethod, Operation>> operationEntryOpt = swagger.getPaths().entrySet().stream()
                .filter(e -> e.getKey().endsWith(endpoint))
                .flatMap(e -> e.getValue().getOperationMap().entrySet().stream())
                .filter(e -> e.getKey() == requiredHttpMethodOpt.get())
                .findAny();

        if(!operationEntryOpt.isPresent()) {
            return empty();
        }

        return findInOperationEntry(propertyName, swagger, operationEntryOpt.get());
    }

    private Optional<SwaggerEndpointData> findInOperationEntry(String propertyName, Swagger swagger, Map.Entry<HttpMethod, Operation> operationEntry) {
        Operation operation = operationEntry.getValue();
        Optional<SwaggerEndpointData> swaggerEndpointDataOpt = operation.getParameters().stream()
                .filter(p -> p.getIn().equals("path") || p.getIn().equals("query") || p.getIn().equals("header"))
                .filter(p -> p.getName().equals(propertyName))
                .map(p -> SwaggerEndpointData.builder()
                        .parameter(propertyName)
                        .in(p.getIn())
                        .parameterDescription(p.getDescription())
                        .parameterRequired(p.getRequired())
                        .build()).findAny();

        if(swaggerEndpointDataOpt.isPresent()) {
            return swaggerEndpointDataOpt;
        }

        List<String> refObjects = operation.getParameters().stream()
                .filter(p -> p.getIn().equals("body"))
                .map(p -> {
                    if(p instanceof BodyParameter) {
                        BodyParameter bodyParameter = ((BodyParameter) p);
                        if(bodyParameter.getSchema() instanceof RefModel) {
                            RefModel refModel = ((RefModel) bodyParameter.getSchema());
                            return ofNullable(refModel.getSimpleRef());
                        }
                    }
                    return Optional.<String>empty();
                }).filter(Optional::isPresent)
                .map(Optional::get).collect(toList());

        if(refObjects.isEmpty()) {
            return empty();
        }

        return refObjects.stream().map(obj -> findInObjectDefinition(swagger, obj, propertyName))
                .filter(Optional::isPresent)
                .map(Optional::get)
                .findAny();
    }

    private Optional<SwaggerEndpointData> findInObjectDefinition(Swagger swagger, String obj, String reqProperty) {
        Optional<Model> modelOptional = objectDefinition(swagger, obj);
        if(modelOptional.isPresent()) {
            for(Map.Entry<String, Property> entry : modelOptional.get().getProperties().entrySet()) {
                Optional<SwaggerEndpointData> swaggerEndpointDataOpt = parseParameter(reqProperty, entry.getKey(), entry.getValue());
                if(swaggerEndpointDataOpt.isPresent()) {
                    return swaggerEndpointDataOpt;
                }
            }
        }

        return empty();
    }

    private Optional<SwaggerEndpointData> parseParameter(String reqProperty, String currentProp, Property property) {
        if(!reqProperty.equals(currentProp)) {
            if(property instanceof RefProperty) {
                RefProperty refProperty = (RefProperty) property;
                return findInObjectDefinition(swagger, refProperty.getSimpleRef(), reqProperty);
            } else if(property instanceof ArrayProperty) {
                ArrayProperty arrayProperty = (ArrayProperty) property;
                return parseParameter(reqProperty, currentProp, arrayProperty.getItems());
            } else {
                return empty();
            }
        }

        SwaggerEndpointData.SwaggerEndpointDataBuilder swaggerEndpointDataBuilder = SwaggerEndpointData.builder()
                .in("body")
                .parameter(reqProperty)
                .parameterDescription(property.getDescription())
                .parameterType(property.getType())
                .parameterRequired(property.getRequired());

        if(property instanceof StringProperty) {
            StringProperty stringProperty = (StringProperty) property;
            return Optional.of(swaggerEndpointDataBuilder
                    .parameterDefault(stringProperty.getDefault())
                    .enumValues(toListString(stringProperty.getEnum())).build());
        } else if(property instanceof IntegerProperty) {
            IntegerProperty integerProperty = (IntegerProperty) property;
            return Optional.of(swaggerEndpointDataBuilder
                    .parameterDefault(ofNullable(integerProperty.getDefault()).map(String::valueOf).orElse(""))
                    .enumValues(toListString(integerProperty.getEnum())).build());
        } else if(property instanceof LongProperty) {
            LongProperty longProperty = (LongProperty) property;
            return Optional.of(swaggerEndpointDataBuilder
                    .parameterDefault(ofNullable(longProperty.getDefault()).map(String::valueOf).orElse(""))
                    .enumValues(toListString(longProperty.getEnum())).build());
        }

        return Optional.of(swaggerEndpointDataBuilder.enumValues(emptyList()).build());
    }

    private static Optional<Model> objectDefinition(Swagger swagger, String objectName) {
        return swagger.getDefinitions().entrySet().stream()
                .filter(e -> e.getKey().equals(objectName))
                .map(Map.Entry::getValue)
                .findAny();
    }

    private void loadSwagger() {
        if(isNull(swagger)) {
            this.swagger = new SwaggerParser().read(swaggerFile);
        }
    }

    private Optional<HttpMethod> parseHttpMethod(String httpMethod) {
        return Stream.of(HttpMethod.values())
                .filter(m -> m.name().equals(httpMethod))
                .findAny();
    }

    private List<String> toListString(List<?> list) {
        return ofNullable(list).orElse(emptyList()).stream()
                .map(String::valueOf).collect(toList());
    }
}
