package br.com.swaggerparser;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
public class SwaggerEndpointData {
    private String in;
    private String parameter;
    private String parameterType;
    private String parameterDescription;
    private String parameterDefault;
    private Boolean parameterRequired;
    private List<String> enumValues;

    @Builder
    public SwaggerEndpointData(String in, String parameter, String parameterType, String parameterDescription, String parameterDefault, Boolean parameterRequired, List<String> enumValues) {
        this.in = in;
        this.parameter = parameter;
        this.parameterType = parameterType;
        this.parameterDescription = parameterDescription;
        this.parameterDefault = parameterDefault;
        this.parameterRequired = parameterRequired;
        this.enumValues = enumValues;
    }
}
