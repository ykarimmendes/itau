package br.com.filereader;

import br.com.sqlparser.ConstraintColumnsData;

public class ConstraintColumnsDataReader extends CsvReader<ConstraintColumnsData> {

    @Override
    protected ConstraintColumnsData mapToObject(String[] lineValues) {
        return ConstraintColumnsData.builder()
                .tableName(lineValues[0])
                .columnName(lineValues[1])
                .constraintName(lineValues[2])
                .constraintType(lineValues[3])
                .constraintSearchCondition(lineValues[4])
                .constraintStatus(lineValues[5]).build();
    }
}
