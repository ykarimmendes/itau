package br.com.filereader;

import br.com.sqlparser.TableColumnsData;

public class TableColumnsDataReader extends CsvReader<TableColumnsData> {

    @Override
    protected TableColumnsData mapToObject(String[] lineValues) {
        return TableColumnsData.builder()
                .tableName(lineValues[0])
                .columnName(lineValues[1])
                .dataType(lineValues[2])
                .dataLength(lineValues[3])
                .dataPrecision(lineValues[4])
                .nullable(lineValues[5]).build();
    }
}
