package br.com.filereader;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Path;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Stream;

import static java.lang.String.format;
import static java.nio.charset.StandardCharsets.UTF_8;
import static java.nio.file.Files.newBufferedReader;
import static java.util.stream.Collectors.toCollection;

public abstract class DsvReader<T> {

    private final String delimiter;

    public DsvReader(String delimiter) {
        this.delimiter = delimiter;
    }

    protected abstract T mapToObject(String[] lineValues);

    public List<T> read(Path csvFile, boolean skipHeader) {
        try(BufferedReader bufferedReader = newBufferedReader(csvFile, UTF_8)) {
            Stream<String> lineStream;
            if(skipHeader) {
                lineStream = bufferedReader.lines().skip(1);
            } else {
                lineStream = bufferedReader.lines();
            }

            return lineStream
                    .map(this::splitLine)
                    .map(this::mapToObject)
                    .collect(toCollection(LinkedList::new));
        } catch (IOException e) {
            throw new IllegalArgumentException(format("Failed to read file: [%s]", csvFile));
        }
    }

    protected String[] splitLine(String line) {
        return line.split(delimiter);
    }
}
