package br.com.filereader;

import br.com.sqlparser.IndexData;

public class IndexDataReader extends CsvReader<IndexData> {

    @Override
    protected IndexData mapToObject(String[] lineValues) {
        return IndexData.builder()
                .tableName(lineValues[0])
                .columnName(lineValues[1])
                .indexName(lineValues[2])
                .indexType(lineValues[3])
                .uniqueness(lineValues[4]).build();
    }
}
