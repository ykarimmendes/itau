package br.com.filereader;

public abstract class CsvReader<T> extends DsvReader<T> {

    private static final String COMMA_SEP = ";";

    public CsvReader() {
        super(COMMA_SEP);
    }
}
