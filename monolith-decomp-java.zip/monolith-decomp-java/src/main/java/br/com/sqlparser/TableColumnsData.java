package br.com.sqlparser;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;

@Getter
public class TableColumnsData extends TableColumnData {
    private String dataType;
    private String dataLength;
    private String dataPrecision;
    private String nullable;
    private String dataDefault;

    @Builder
    public TableColumnsData(String tableName, String columnName, String dataType, String dataLength, String dataPrecision, String nullable, String dataDefault) {
        super(tableName, columnName);
        this.dataType = dataType;
        this.dataLength = dataLength;
        this.dataPrecision = dataPrecision;
        this.nullable = nullable;
        this.dataDefault = dataDefault;
    }
}
