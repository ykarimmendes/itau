package br.com.sqlparser;

import lombok.Builder;
import lombok.Getter;

@Getter
public class ConstraintColumnsData extends TableColumnData {
    private String constraintName;
    private String constraintType;
    private String constraintSearchCondition;
    private String constraintStatus;

    @Builder
    public ConstraintColumnsData(String tableName, String columnName, String constraintName, String constraintType, String constraintSearchCondition, String constraintStatus) {
        super(tableName, columnName);
        this.constraintName = constraintName;
        this.constraintType = constraintType;
        this.constraintSearchCondition = constraintSearchCondition;
        this.constraintStatus = constraintStatus;
    }
}
