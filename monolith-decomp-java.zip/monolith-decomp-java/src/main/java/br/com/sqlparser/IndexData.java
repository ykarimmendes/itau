package br.com.sqlparser;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;

@Getter
public class IndexData extends TableColumnData {
    private String indexName;
    private String indexType;
    private String uniqueness;

    @Builder
    public IndexData(String tableName, String columnName, String indexName, String indexType, String uniqueness) {
        super(tableName, columnName);
        this.indexName = indexName;
        this.indexType = indexType;
        this.uniqueness = uniqueness;
    }
}
