package br.com.javaparser.methodparser.strategy.impl;

import br.com.javaparser.methodparser.line.vo.MethodLineObject;
import br.com.javaparser.methodparser.strategy.FilterStrategy;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class ClassAndMethodFilterStrategy implements FilterStrategy {

    protected List<Map<String, Set<String>>> classMethods;

    public ClassAndMethodFilterStrategy() {
    }

    public ClassAndMethodFilterStrategy(List<Map<String, Set<String>>> classMethods) {
        this.classMethods = classMethods;
    }

    @Override
    public Stream<Entry<String, Map<String, Set<MethodLineObject>>>> filter(Stream<Entry<String, Map<String, Set<MethodLineObject>>>> classMethodEntryStream) {
        return classMethodEntryStream
                .filter(this::filterByClassAndMethod)
                .peek(e -> keepMethod(e.getKey(), e.getValue()));
    }

    private boolean filterByClassAndMethod(Entry<String, Map<String, Set<MethodLineObject>>> stringMapEntry) {
        return classMethods.stream()
                .filter(cm -> cm.keySet().contains(stringMapEntry.getKey()))
                .findAny().isPresent();
    }

    private void keepMethod(String clazz, Map<String, Set<MethodLineObject>> methodCalls) {
        methodCalls.entrySet()
                .removeIf(e -> methodToKeep(clazz).negate().test(e.getKey()));
    }

    private Predicate<String> methodToKeep(String clazz) {
        return m -> classMethods.stream()
                .filter(map -> map.containsKey(clazz))
                .map(map -> map.get(clazz))
                .flatMap(l -> l.stream())
                .filter(cm -> cm.equals(m))
                .findAny().isPresent();
    }
}