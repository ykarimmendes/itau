package br.com.javaparser.methodparser.line.processor;

import br.com.javaparser.methodparser.line.vo.ClassAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.ClassGenericLineObject;
import br.com.javaparser.methodparser.line.vo.FieldAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.FieldTypeLineObject;
import br.com.javaparser.methodparser.line.vo.MethodAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.MethodLineObject;
import br.com.javaparser.methodparser.line.parser.ClassAnnotationLineParser;
import br.com.javaparser.methodparser.line.parser.ClassGenericLineParser;
import br.com.javaparser.methodparser.line.parser.FieldAnnotationLineParser;
import br.com.javaparser.methodparser.line.parser.FieldTypeLineParser;
import br.com.javaparser.methodparser.line.parser.LineParser;
import br.com.javaparser.methodparser.line.parser.MethodAnnotationLineParser;
import br.com.javaparser.methodparser.line.parser.MethodLineParser;

import java.util.Map;
import java.util.Optional;
import java.util.Set;

public class AllEntriesDataProcessor extends EmptyDataProcessor {

    private final LineParser<Map<String, Map<String, Set<MethodLineObject>>>> METHOD_LINE_PROCESSOR = new MethodLineParser();
    private final LineParser<Map<String, Set<ClassAnnotationLineObject>>> CLASS_ANNOTATION_LINE_PROCESSOR = new ClassAnnotationLineParser();
    private final LineParser<Map<String, Map<String, Set<MethodAnnotationLineObject>>>> METHOD_ANNOTATION_LINE_PROCESSOR = new MethodAnnotationLineParser();
    private final LineParser<Map<String, Set<ClassGenericLineObject>>> CLASS_GENERIC_LINE_PROCESSOR = new ClassGenericLineParser();
    private final LineParser<Map<String, Map<String, Set<FieldAnnotationLineObject>>>> FIELD_ANNOTATION_LINE_PROCESSOR = new FieldAnnotationLineParser();
    private final LineParser<Map<String, Map<String, FieldTypeLineObject>>> FIELD_TYPE_LINE_PROCESSOR = new FieldTypeLineParser();

    @Override
    public Optional<LineParser<Map<String, Map<String, Set<MethodLineObject>>>>> methodLineProcessor() {
        return Optional.of(METHOD_LINE_PROCESSOR);
    }

    @Override
    public Optional<LineParser<Map<String, Set<ClassAnnotationLineObject>>>> classAnnotationLineProcessorData() {
        return Optional.of(CLASS_ANNOTATION_LINE_PROCESSOR);
    }

    @Override
    public Optional<LineParser<Map<String, Map<String, Set<MethodAnnotationLineObject>>>>> methodAnnotationLineProcessorData() {
        return Optional.of(METHOD_ANNOTATION_LINE_PROCESSOR);
    }

    @Override
    public Optional<LineParser<Map<String, Set<ClassGenericLineObject>>>> classGenericLineProcessorData() {
        return Optional.of(CLASS_GENERIC_LINE_PROCESSOR);
    }

    @Override
    public Optional<LineParser<Map<String, Map<String, Set<FieldAnnotationLineObject>>>>> fieldAnnotationLineProcessorData() {
        return Optional.of(FIELD_ANNOTATION_LINE_PROCESSOR);
    }

    @Override
    public Optional<LineParser<Map<String, Map<String, FieldTypeLineObject>>>> fieldTypeLineProcessorData() {
        return Optional.of(FIELD_TYPE_LINE_PROCESSOR);
    }
}
