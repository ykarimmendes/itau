package br.com.javaparser.methodparser.line.vo;

import lombok.Data;

@Data
public class ClassLineObject extends LineObject {
    private final String classUsed;

    public ClassLineObject(String originType, String originClass, String classUsed) {
        super(originType, originClass);
        this.classUsed = classUsed;
    }
}
