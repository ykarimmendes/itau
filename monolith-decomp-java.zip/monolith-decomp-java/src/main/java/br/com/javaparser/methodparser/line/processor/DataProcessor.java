package br.com.javaparser.methodparser.line.processor;

import br.com.javaparser.methodparser.line.vo.ClassAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.ClassGenericLineObject;
import br.com.javaparser.methodparser.line.vo.FieldAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.FieldTypeLineObject;
import br.com.javaparser.methodparser.line.vo.MethodAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.MethodLineObject;
import br.com.javaparser.methodparser.line.parser.LineParser;

import java.util.Map;
import java.util.Optional;
import java.util.Set;

public interface DataProcessor {
    Optional<LineParser<Map<String, Map<String, Set<MethodLineObject>>>>> methodLineProcessor();
    Optional<LineParser<Map<String, Set<ClassAnnotationLineObject>>>> classAnnotationLineProcessorData();
    Optional<LineParser<Map<String, Map<String, Set<MethodAnnotationLineObject>>>>> methodAnnotationLineProcessorData();
    Optional<LineParser<Map<String, Set<ClassGenericLineObject>>>> classGenericLineProcessorData();
    Optional<LineParser<Map<String, Map<String, Set<FieldAnnotationLineObject>>>>> fieldAnnotationLineProcessorData();
    Optional<LineParser<Map<String, Map<String, FieldTypeLineObject>>>> fieldTypeLineProcessorData();
}
