package br.com.javaparser.methodparser.line.visitor.impl;

import br.com.javaparser.methodparser.line.vo.ClassAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.ClassGenericLineObject;
import br.com.javaparser.methodparser.line.vo.FieldAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.MethodAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.MethodLineObject;
import br.com.javaparser.methodparser.line.visitor.LineObjectVisitor;

public class EmptyLineObjectVisitor implements LineObjectVisitor {
    @Override
    public void startTopClassVisit(int level, String clazz) {

    }

    @Override
    public void startTopMethodVisit(int level, String clazz, String method) {

    }

    @Override
    public void visit(int level, String origin, ClassGenericLineObject classGenericLineObject, ClassAnnotationLineObject classAnnotationLineObject) {

    }

    @Override
    public void visit(int level, ClassAnnotationLineObject classAnnotationLineObject) {

    }

    @Override
    public void visit(int level, String clazz, String method, FieldAnnotationLineObject fieldAnnotationLineObject) {

    }

    @Override
    public void visit(int level, String clazz, String method, MethodAnnotationLineObject methodAnnotationLineObject) {

    }

    @Override
    public void visit(int level, MethodLineObject methodLineObject) {

    }

    @Override
    public void endTopMethodVisit(int level, String clazz, String method) {

    }

    @Override
    public void endTopClassVisit(int level, String clazz) {

    }
}
