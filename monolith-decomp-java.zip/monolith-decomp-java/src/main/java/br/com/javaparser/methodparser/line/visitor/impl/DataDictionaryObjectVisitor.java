package br.com.javaparser.methodparser.line.visitor.impl;

import br.com.javaparser.methodparser.line.vo.ClassAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.ClassGenericLineObject;
import br.com.javaparser.methodparser.line.vo.FieldAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.MethodAnnotationLineObject;
import br.com.javaparser.methodparser.line.visitor.datadictionary.DataDictionaryLifeCycleDelegate;
import lombok.Builder;
import lombok.Data;
import lombok.Singular;

import java.util.Set;
import java.util.function.Predicate;

@Data
@Builder
public class DataDictionaryObjectVisitor extends EmptyLineObjectVisitor {

    @Singular("addToIgnoreDestClass")
    private Set<String> ignoreDestClass;

    @Singular("addToIgnoreDestMethod")
    private Set<String> ignoreDestMethod;

    @Singular("addToIgnoreAnnotations")
    private Set<String> ignoreAnnotations;

    private DataDictionaryLifeCycleDelegate dataDictionaryLifeCycleDelegate;

    @Builder
    public DataDictionaryObjectVisitor(Set<String> ignoreDestClass, Set<String> ignoreDestMethod, Set<String> ignoreAnnotations, DataDictionaryLifeCycleDelegate dataDictionaryLifeCycleDelegate) {
        this.ignoreDestClass = ignoreDestClass;
        this.ignoreDestMethod = ignoreDestMethod;
        this.ignoreAnnotations = ignoreAnnotations;
        this.dataDictionaryLifeCycleDelegate = dataDictionaryLifeCycleDelegate;
    }

    @Override
    public void startTopMethodVisit(int level, String clazz, String method) {
        dataDictionaryLifeCycleDelegate.recreateDataDictionaryEntry();
    }

    @Override
    public void endTopMethodVisit(int level, String clazz, String method) {
        dataDictionaryLifeCycleDelegate.closeCurrentDataDictionaryAndClear();
    }

    @Override
    public void visit(int level, String origin, ClassGenericLineObject classGenericLineObject, ClassAnnotationLineObject classAnnotationLineObject) {
        if(contains(ignoreAnnotations).test(classAnnotationLineObject.getAnnotation()) ||
                !classAnnotationLineObject.getAnnotation().contains(".Table")) {
            return;
        }

        dataDictionaryLifeCycleDelegate.putToClassTableAnnotation(classGenericLineObject.getGeneric(), classAnnotationLineObject);
    }

    @Override
    public void visit(int level, String clazz, String method, FieldAnnotationLineObject fieldAnnotationLineObject) {
        if(contains(ignoreAnnotations).test(fieldAnnotationLineObject.getAnnotation()) ||
                !fieldAnnotationLineObject.getAnnotation().contains(".Column")) {
            return;
        }

        dataDictionaryLifeCycleDelegate.putToClassFieldAnnotation(clazz, fieldAnnotationLineObject);
    }

    @Override
    public void visit(int level, String clazz, String method, MethodAnnotationLineObject methodAnnotationLineObject) {
        if(contains(ignoreAnnotations).test(methodAnnotationLineObject.getAnnotation()) ||
                !methodAnnotationLineObject.getAnnotation().contains("org.springframework.web.bind.annotation.RequestMapping")) {
            return;
        }

        dataDictionaryLifeCycleDelegate.addInfoToDataDictionaryEntry(methodAnnotationLineObject);
    }

    private Predicate<String> contains(Set<String> contains) {
        return s -> contains.stream()
                .filter(i -> s.contains(i))
                .findFirst().isPresent();
    }
}
