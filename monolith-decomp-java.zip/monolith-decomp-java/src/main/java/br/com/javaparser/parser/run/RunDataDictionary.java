package br.com.javaparser.parser.run;

import br.com.filereader.ConstraintColumnsDataReader;
import br.com.filereader.CsvReader;
import br.com.filereader.IndexDataReader;
import br.com.filereader.TableColumnsDataReader;
import br.com.javaparser.methodparser.line.processor.AllEntriesDataProcessor;
import br.com.javaparser.methodparser.line.processor.DataProcessor;
import br.com.javaparser.methodparser.line.visitor.datadictionary.DataDictionaryLifeCycleDelegate;
import br.com.javaparser.methodparser.line.visitor.impl.DataDictionaryObjectVisitor;
import br.com.javaparser.methodparser.strategy.FilterContext;
import br.com.javaparser.parser.JavaMethodTreeParser;
import br.com.sqlparser.TableColumnData;
import br.com.swaggerparser.SwaggerEndpointParser;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

import static java.lang.String.format;
import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.groupingBy;

public class RunDataDictionary implements ParserRun {

    @Override
    public void run(Path inputFile, FilterContext filterContext) throws IOException {
        JavaMethodTreeParser javaMethodTreeParser = setupBaseJavaMethodTreeParser();
        DataProcessor dataProcessor = new AllEntriesDataProcessor();
        javaMethodTreeParser.loadParseFile(inputFile, dataProcessor);

        String databaseDataFilesDir = "./input";
        String swaggerFile = "./input/swagger-27.3-rc4.json";

        DataDictionaryObjectVisitor dataDictionaryObjectVisitor = buildDataDictionaryLineObjectVisitor(dataProcessor, databaseDataFilesDir, swaggerFile);
        javaMethodTreeParser.visit(dataDictionaryObjectVisitor, filterContext);
        dataDictionaryObjectVisitor.getDataDictionaryLifeCycleDelegate().printDictionary();
    }

    public JavaMethodTreeParser setupBaseJavaMethodTreeParser() {
        JavaMethodTreeParser javaMethodTreeParser = new JavaMethodTreeParser();
        javaMethodTreeParser.addAlternateClassImplNameFormat("%sImpl");
        javaMethodTreeParser.addAlternateClassImplNameFormat("I%s");
        javaMethodTreeParser.debugEnabled(false);

        return javaMethodTreeParser;
    }

    public DataDictionaryObjectVisitor buildDataDictionaryLineObjectVisitor(DataProcessor dataProcessor, String databaseDataFilesDir, String swaggerFile) {
        return DataDictionaryObjectVisitor.builder()
                .dataDictionaryLifeCycleDelegate(buildDataDictionaryLifeCycleDelegate(dataProcessor, databaseDataFilesDir, swaggerFile))
                .addToIgnoreDestClass("java.")
                .addToIgnoreDestClass("org.slf4j")
                .addToIgnoreDestClass("org.apache.commons")
                .addToIgnoreDestClass("org.springframework.jdbc.core")
                .addToIgnoreDestMethod("java.")
                .addToIgnoreAnnotations("java.lang.Deprecated")
                .addToIgnoreAnnotations("org.springframework.transaction.annotation.Transactional")
                .addToIgnoreAnnotations("javax.persistence.Entity")
                .addToIgnoreAnnotations("org.hibernate.annotations.DynamicInsert")
                .addToIgnoreAnnotations("org.hibernate.annotations.DynamicUpdate")
                .addToIgnoreAnnotations("br.com.bradesco.next.common.annotation.PrimaryKey")
                .addToIgnoreAnnotations("com.fasterxml.jackson.annotation.JsonIgnoreProperties")
                .addToIgnoreAnnotations("javax.validation.constraints")
                .addToIgnoreAnnotations("javax.persistence.ManyToOne")
                .addToIgnoreAnnotations("javax.persistence.Convert")
                .addToIgnoreAnnotations("javax.persistence.Id")
                .addToIgnoreAnnotations("org.springframework.web.bind.annotation.CrossOrigin")
                .addToIgnoreAnnotations("org.springframework.validation.annotation.Validated")
                .addToIgnoreAnnotations("org.springframework.web.bind.annotation.ResponseStatus")
                .build();
    }

    private DataDictionaryLifeCycleDelegate buildDataDictionaryLifeCycleDelegate(DataProcessor dataProcessor, String databaseDataFilesDir, String swaggerFile) {
        DataDictionaryLifeCycleDelegate dataDictionaryLifeCycleDelegate = new DataDictionaryLifeCycleDelegate();
        dataDictionaryLifeCycleDelegate.setDataProcessor(dataProcessor);
        addSwaggerEndpointParser(dataDictionaryLifeCycleDelegate, swaggerFile);
        addReferenceFileData(dataDictionaryLifeCycleDelegate, databaseDataFilesDir);

        return dataDictionaryLifeCycleDelegate;
    }

    private void addSwaggerEndpointParser(DataDictionaryLifeCycleDelegate dataDictionaryLifeCycleDelegate, String swaggerFile) {
        if(!new File(swaggerFile).exists()) {
            System.err.println(format("Cannot access file: [%s]. It will not be used during data dictionary creation.", swaggerFile));
            return;
        }

        SwaggerEndpointParser swaggerEndpointParser = new SwaggerEndpointParser(swaggerFile);
        dataDictionaryLifeCycleDelegate.setSwaggerEndpointParser(swaggerEndpointParser);
    }

    private void addReferenceFileData(DataDictionaryLifeCycleDelegate dataDictionaryLifeCycleDelegate, String databaseDataFilesDir) {
        Path consColumnsCsvFile = Paths.get(databaseDataFilesDir, "constraint-coluns-data.csv");
        Path indexColumnsCsvFile = Paths.get(databaseDataFilesDir, "index-data.csv");
        Path tableColumnsCsvFile = Paths.get(databaseDataFilesDir, "all-table-columns-data.csv");

        dataDictionaryLifeCycleDelegate.addConstraintColumnsData(readConvertToTableColumnMap(consColumnsCsvFile, new ConstraintColumnsDataReader()));
        dataDictionaryLifeCycleDelegate.addIndexData(readConvertToTableColumnMap(indexColumnsCsvFile, new IndexDataReader()));
        dataDictionaryLifeCycleDelegate.addTableColumnsData(readConvertToTableColumnMap(tableColumnsCsvFile, new TableColumnsDataReader()));
    }

    private <T extends TableColumnData> Map<String, Map<String, List<T>>> readConvertToTableColumnMap(Path csv, CsvReader<T> csvReader) {
        System.err.println("Reading file: [" + csv + "]");
        List<T> fileRead = readFromCsv(csv, csvReader);

        Map<String, Map<String, List<T>>> ret = mapToTableColumnStructure(fileRead);

        System.err.println("Read: [" + fileRead.size() + "] lines - Merged to: [" + ret.size() + "] map entries");
        return ret;
    }

    private <T extends TableColumnData> List<T> readFromCsv(Path csvFile, CsvReader<T> csvReader) {
        if(!csvFile.toFile().exists()) {
            System.err.println(format("Cannot access file: [%s]. It will not be used during data dictionary creation.", csvFile));
            return emptyList();
        }

        return csvReader.read(csvFile, true);
    }

    private <T extends TableColumnData> Map<String, Map<String, List<T>>> mapToTableColumnStructure(List<T> data) {
        return data.stream()
                .collect(groupingBy(TableColumnData::getTableName, groupingBy(TableColumnData::getColumnName)));
    }
}
