package br.com.javaparser.methodparser.line.vo;

import lombok.Data;

@Data
public class LineObject {
    protected String originType;
    protected String originClass;
    protected String originMethodSignature;

    public LineObject(String originType, String originClass, String originMethodSignature) {
        this.originType = originType;
        this.originClass = originClass;
        this.originMethodSignature = originMethodSignature;
    }

    public LineObject(String originType, String originClass) {
        this.originType = originType;
        this.originClass = originClass;
    }
}