package br.com.javaparser.methodparser.strategy;

import br.com.javaparser.methodparser.line.vo.MethodLineObject;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Stream;

public interface FilterStrategy {
    Stream<Entry<String, Map<String, Set<MethodLineObject>>>> filter(Stream<Entry<String, Map<String, Set<MethodLineObject>>>> classMethodEntryStream);
}
