package br.com.javaparser.methodparser.line.parser;

import br.com.javaparser.methodparser.line.vo.FieldTypeLineObject;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static br.com.javaparser.parser.JavaMethodTreeParser.CLASS_PATTERN_GROUP;
import static br.com.javaparser.parser.JavaMethodTreeParser.FIELD_NAME_PATTERN_GROUP;
import static br.com.javaparser.methodparser.line.vo.LineObjectFactory.newFieldTypeLineObject;
import static java.util.regex.Pattern.compile;

public class FieldTypeLineParser implements LineParser<Map<String, Map<String, FieldTypeLineObject>>> {

    private static final String FIELD_TYPE_LINE_PATTERN_STR = "(FTP):" + CLASS_PATTERN_GROUP + " "
            + FIELD_NAME_PATTERN_GROUP + ":" + CLASS_PATTERN_GROUP;
    private static final Pattern FIELD_TYPE_LINE_PATTERN = compile(FIELD_TYPE_LINE_PATTERN_STR);

    private final Map<String, Map<String, FieldTypeLineObject>> FIELD_TYPE_LINE_MAP;

    public FieldTypeLineParser() {
        this.FIELD_TYPE_LINE_MAP = new LinkedHashMap<>();
    }

    @Override
    public Pattern linePattern() {
        return FIELD_TYPE_LINE_PATTERN;
    }

    @Override
    public Consumer<Matcher> lineConsumer() {
        return this::consumeClassFieldTypeLine;
    }

    @Override
    public Map<String, Map<String, FieldTypeLineObject>> lineData() {
        return FIELD_TYPE_LINE_MAP;
    }

    private void consumeClassFieldTypeLine(Matcher matcher) {
        FieldTypeLineObject fieldTypeLineObject = newFieldTypeLineObject(matcher);
        FIELD_TYPE_LINE_MAP.computeIfAbsent(fieldTypeLineObject.getOriginClass(), v -> new LinkedHashMap<>())
                .put(fieldTypeLineObject.getField(), fieldTypeLineObject);
    }
}
