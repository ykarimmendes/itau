package br.com.javaparser.analyzer;

import org.apache.bcel.classfile.EmptyVisitor;
import org.apache.bcel.classfile.Field;
import org.apache.bcel.classfile.JavaClass;

import static java.lang.String.format;

public class FieldVisitor extends EmptyVisitor {
    private JavaClass javaClass;
    private final String format;

    public FieldVisitor(JavaClass javaClass) {
        this.javaClass = javaClass;
        this.format = "FTP:" + javaClass.getClassName() + " %s:%s";
    }

    public void start() {
        for(Field field : javaClass.getFields()) {
            field.accept(this);
        }
    }

    public void visitField(Field field) {
        System.out.println(format(format, field.getName(), field.getType()));
        new AnnotationEntryVisitor(javaClass, field).startField();
    }
}
