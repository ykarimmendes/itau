package br.com.javaparser.methodparser.line.vo;

import lombok.Data;

@Data
public class MethodLineObject extends LineObject {
    protected String destType;
    protected String destClass;
    protected String destMethodSignature;

    public MethodLineObject(String destType, String destClass, String destMethodSignature) {
        super(null, null, null);
        this.destType = destType;
        this.destClass = destClass;
        this.destMethodSignature = destMethodSignature;
    }

    public MethodLineObject(String originType, String originClass, String originMethodSignature, String destType, String destClass, String destMethodSignature) {
        super(originType, originClass, originMethodSignature);
        this.destType = destType;
        this.destClass = destClass;
        this.destMethodSignature = destMethodSignature;
    }

    public MethodLineObject(String destClass, MethodLineObject methodLineObject) {
        super(methodLineObject.getOriginType(), methodLineObject.getOriginClass(), methodLineObject.getOriginMethodSignature());
        this.destType = methodLineObject.getDestType();
        this.destMethodSignature = methodLineObject.getDestMethodSignature();
        this.destClass = destClass;
    }
}
