package br.com.javaparser.methodparser.line.visitor.impl;

import br.com.javaparser.methodparser.line.vo.ClassAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.ClassGenericLineObject;
import br.com.javaparser.methodparser.line.vo.FieldAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.MethodAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.MethodLineObject;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Singular;

import java.util.Set;
import java.util.function.Predicate;

import static java.util.Objects.isNull;

@AllArgsConstructor
@Data
@Builder
public class SysOutLineObjectVisitor extends EmptyLineObjectVisitor {

    @Singular("addToIgnoreDestClass")
    private Set<String> ignoreDestClass;

    @Singular("addToIgnoreDestMethod")
    private Set<String> ignoreDestMethod;

    @Singular("addToIgnoreAnnotations")
    private Set<String> ignoreAnnotations;

    @Override
    public void startTopClassVisit(int level, String clazz) {
        System.out.println(paddingString(level) + "[" + level + "] Start Top Class: [" + clazz + "]");
    }

    @Override
    public void endTopClassVisit(int level, String clazz) {
        System.out.println(paddingString(level) + "[" + level + "] End Top Class: [" + clazz + "]");
    }

    @Override
    public void startTopMethodVisit(int level, String clazz, String method) {
        System.out.println(paddingString(level) + "[" + level + "] Start Top Method: [" + clazz + "][" + method + "]");
    }

    @Override
    public void endTopMethodVisit(int level, String clazz, String method) {
        System.out.println(paddingString(level) + "[" + level + "] End Top Method: [" + clazz + "][" + method + "]");
    }

    @Override
    public void visit(int level, String origin, ClassGenericLineObject classGenericLineObject, ClassAnnotationLineObject classAnnotationLineObject) {
        if(contains(ignoreAnnotations).test(classAnnotationLineObject.getAnnotation())) {
            return;
        }

        System.out.println(paddingString(level) + "[" + level + "] Class Generic - From: [" + origin + "] [" + classGenericLineObject.getGeneric() + "] - [" + classAnnotationLineObject.getAnnotation() + "]");
    }

    @Override
    public void visit(int level, ClassAnnotationLineObject classAnnotationLineObject) {
        if(contains(ignoreAnnotations).test(classAnnotationLineObject.getAnnotation())) {
            return;
        }

        System.out.println(paddingString(level) + "[" + level + "] Annotation: [" + classAnnotationLineObject.getAnnotation() + "]");
    }

    @Override
    public void visit(int level, String clazz, String method, FieldAnnotationLineObject fieldAnnotationLineObject) {
        if(contains(ignoreAnnotations).test(fieldAnnotationLineObject.getAnnotation())) {
            return;
        }

        String fieldName = (method.length()>=3) ? method.substring(0, 3) : method;

        System.out.println(paddingString(level) + "[" + level + "] Get/set: [" + fieldName + "][" + fieldAnnotationLineObject.getField() + "] -> [" + fieldAnnotationLineObject.getAnnotation() + "]");
    }

    @Override
    public void visit(int level, String clazz, String method, MethodAnnotationLineObject methodAnnotationLineObject) {
        if(contains(ignoreAnnotations).test(methodAnnotationLineObject.getAnnotation())) {
            return;
        }

        System.out.println(paddingString(level) + "[" + level + "] Annotation: [" + methodAnnotationLineObject.getAnnotation() + "]");
    }

    @Override
    public void visit(int level, MethodLineObject methodLineObject) {
        if(isNull(methodLineObject.getOriginClass())
                || isNull(methodLineObject.getOriginMethodSignature())
                || contains(ignoreDestClass).test(methodLineObject.getDestClass())) {
            return;
        }

        System.out.println(paddingString(level) + "[" + level + "] Method: [" + methodLineObject.getDestClass() + "." + methodLineObject.getDestMethodSignature() + "]");
    }

    private Predicate<String> contains(Set<String> contains) {
        return s -> contains.stream()
                .filter(i -> s.contains(i))
                .findFirst().isPresent();
    }

    private String paddingString(int n) {
        return new String(new char[n]).replace("\0", " ");
    }
}
