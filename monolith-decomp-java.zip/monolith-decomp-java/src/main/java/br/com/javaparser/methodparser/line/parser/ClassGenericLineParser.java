package br.com.javaparser.methodparser.line.parser;

import br.com.javaparser.methodparser.line.vo.ClassGenericLineObject;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static br.com.javaparser.parser.JavaMethodTreeParser.CLASS_PATTERN_GROUP;
import static br.com.javaparser.methodparser.line.vo.LineObjectFactory.newClassGenericLineObject;

public class ClassGenericLineParser implements LineParser<Map<String, Set<ClassGenericLineObject>>> {

    private static final String CLASS_GENERIC_LINE_PATTERN_STR = "(GTP):" + CLASS_PATTERN_GROUP + " " + CLASS_PATTERN_GROUP;
    private static final Pattern CLASS_GENERIC_LINE_PATTERN = Pattern.compile(CLASS_GENERIC_LINE_PATTERN_STR);

    private final Map<String, Set<ClassGenericLineObject>> CLASS_GENERIC_LINE_MAP;

    public ClassGenericLineParser() {
        this.CLASS_GENERIC_LINE_MAP = new LinkedHashMap<>();
    }

    @Override
    public Pattern linePattern() {
        return CLASS_GENERIC_LINE_PATTERN;
    }

    @Override
    public Consumer<Matcher> lineConsumer() {
        return this::consumeClassGenericLine;
    }

    @Override
    public Map<String, Set<ClassGenericLineObject>> lineData() {
        return CLASS_GENERIC_LINE_MAP;
    }

    private void consumeClassGenericLine(Matcher matcher) {
        ClassGenericLineObject classGenericLineObject = newClassGenericLineObject(matcher);
        CLASS_GENERIC_LINE_MAP.computeIfAbsent(classGenericLineObject.getOriginClass(),
                v -> new LinkedHashSet<>()).add(classGenericLineObject);
    }
}
