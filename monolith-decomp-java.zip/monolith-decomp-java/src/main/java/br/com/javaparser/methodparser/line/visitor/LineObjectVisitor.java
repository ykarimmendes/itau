package br.com.javaparser.methodparser.line.visitor;

import br.com.javaparser.methodparser.line.vo.ClassAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.ClassGenericLineObject;
import br.com.javaparser.methodparser.line.vo.FieldAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.MethodAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.MethodLineObject;

public interface LineObjectVisitor {

    void startTopClassVisit(int level, String clazz);
    void startTopMethodVisit(int level, String clazz, String method);
    void visit(int level, String origin, ClassGenericLineObject classGenericLineObject, ClassAnnotationLineObject classAnnotationLineObject);
    void visit(int level, ClassAnnotationLineObject classAnnotationLineObject);
    void visit(int level, String clazz, String method, FieldAnnotationLineObject fieldAnnotationLineObject);
    void visit(int level, String clazz, String method, MethodAnnotationLineObject methodAnnotationLineObject);
    void visit(int level, MethodLineObject methodLineObject);
    void endTopMethodVisit(int level, String clazz, String method);
    void endTopClassVisit(int level, String clazz);
}
