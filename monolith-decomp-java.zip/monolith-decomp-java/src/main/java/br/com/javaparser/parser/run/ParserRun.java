package br.com.javaparser.parser.run;

import br.com.javaparser.methodparser.strategy.FilterContext;

import java.io.IOException;
import java.nio.file.Path;

public interface ParserRun {
    void run(Path inputFile, FilterContext filterContext) throws IOException;
}
