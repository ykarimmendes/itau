package br.com.javaparser.methodparser.line.visitor.datadictionary;

import br.com.javaparser.methodparser.line.parser.LineParser;
import br.com.javaparser.methodparser.line.processor.DataProcessor;
import br.com.javaparser.methodparser.line.visitor.datadictionary.DataDictionaryEntry.ClassFieldEntry;
import br.com.javaparser.methodparser.line.visitor.datadictionary.DataDictionaryEntry.ConstraintType;
import br.com.javaparser.methodparser.line.visitor.datadictionary.DataDictionaryEntry.TableFieldEntry;
import br.com.javaparser.methodparser.line.vo.ClassAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.FieldAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.FieldTypeLineObject;
import br.com.javaparser.methodparser.line.vo.MethodAnnotationLineObject;
import br.com.sqlparser.ConstraintColumnsData;
import br.com.sqlparser.IndexData;
import br.com.sqlparser.TableColumnsData;
import br.com.swaggerparser.SwaggerEndpointData;
import br.com.swaggerparser.SwaggerEndpointParser;

import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import static java.util.Collections.emptyList;
import static java.util.Optional.empty;
import static java.util.Optional.ofNullable;
import static java.util.regex.Pattern.compile;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toMap;
import static java.util.stream.Collectors.toSet;

public class DataDictionaryLifeCycleDelegate {

    private static final Pattern TABLE_ANN_PATTERN = compile("([\\p{Alnum}\\.]+Table)\\(([\\p{Punct}\\p{Alpha}]+=[\\p{Punct}\\p{Alpha}]+)+\\)");
    private static final Pattern REQUESTMAP_ANN_PATTERN = compile("([\\p{Alnum}\\.]+RequestMapping)\\(([\\p{Graph}]+)\\)");
    private static final Pattern COLUMN_ANN_PATTERN = compile("([\\p{Alnum}\\.]+Column)\\(([\\p{Graph}]+)\\)");

    private List<DataDictionaryEntry> DATA_DIC_ENTRIES;

    private Map<String, String> CLASS_TABLE_ANNOTATION;
    private Map<String, Set<FieldAnnotationLineObject>> CLASS_FIELD_ANNOTATION;
    private Map<String, Map<String, List<ConstraintColumnsData>>> CONS_COLUMNS_DATA;
    private Map<String, Map<String, List<IndexData>>> INDEX_DATA;
    private Map<String, Map<String, List<TableColumnsData>>> TABLE_COLUMNS_DATA;

    private SwaggerEndpointParser swaggerEndpointParser;

    private DataDictionaryEntry dataDictionaryEntry;

    private DataProcessor dataProcessor;

    private boolean hasRequestMapping = false;

    private final Function<String, String> addQuotes = s -> new StringBuilder()
            .append("\"")
            .append(ofNullable(s).orElse(""))
            .append("\"").toString();

    private final String CSV_HEADER = new StringBuilder()
            .append(addQuotes.apply("Http Method")).append(',')
            .append(addQuotes.apply("URI")).append(',')
            .append(addQuotes.apply("Produces")).append(',')
            .append(addQuotes.apply("In")).append(',')
            .append(addQuotes.apply("Param Desc")).append(',')
            .append(addQuotes.apply("Param Default")).append(',')
            .append(addQuotes.apply("Enum Values")).append(',')
            .append(addQuotes.apply("Param Type")).append(',')
            .append(addQuotes.apply("Param Required")).append(',')
            .append(addQuotes.apply("Class Name")).append(',')
            .append(addQuotes.apply("Field Name")).append(',')
            .append(addQuotes.apply("Table Name")).append(',')
            .append(addQuotes.apply("Table Field")).append(',')
            .append(addQuotes.apply("PK")).append(',')
            .append(addQuotes.apply("FK")).append(',')
            .append(addQuotes.apply("Unique")).append(',')
            .append(addQuotes.apply("Nullable")).append(',')
            .append(addQuotes.apply("Table Field Type")).append(',')
            .append(addQuotes.apply("Length")).append(',')
            .append(addQuotes.apply("Precision")).append(',')
            .append(addQuotes.apply("Column Constraints")).toString();

    public DataDictionaryLifeCycleDelegate() {
        this.CLASS_TABLE_ANNOTATION = new HashMap<>();
        this.DATA_DIC_ENTRIES = new LinkedList<>();
        this.CLASS_FIELD_ANNOTATION = new HashMap<>();
        this.CONS_COLUMNS_DATA = new HashMap<>();
        this.INDEX_DATA = new HashMap<>();
        this.TABLE_COLUMNS_DATA = new HashMap<>();
    }

    public void recreateDataDictionaryEntry() {
        setHasRequestMapping(false);
        dataDictionaryEntry = new DataDictionaryEntry();
    }

    public void closeCurrentDataDictionaryAndClear() {
        mergeDataDictionaryTableData();
        if(!hasRequestMapping()) {
            return;
        }

        dataDictionaryEntry.setClosed(true);
        addCurrentDataDictionary();
        clearCurrentRunEntries();
    }

    public void putToClassTableAnnotation(String clazz, ClassAnnotationLineObject classAnnotationLineObject) {
        CLASS_TABLE_ANNOTATION.put(clazz, getTableName(classAnnotationLineObject.getAnnotation()));
    }

    public void putToClassFieldAnnotation(String clazz, FieldAnnotationLineObject fieldAnnotationLineObject) {
        CLASS_FIELD_ANNOTATION.computeIfAbsent(clazz, v -> new HashSet<>())
                .add(fieldAnnotationLineObject);
    }

    public void addInfoToDataDictionaryEntry(MethodAnnotationLineObject methodAnnotationLineObject) {
        setHasRequestMapping(true);
        Map<String, String> keyValue = parseKeyValueAnnotation(REQUESTMAP_ANN_PATTERN, methodAnnotationLineObject.getAnnotation());
        dataDictionaryEntry.setUri(keyValue.getOrDefault("value", keyValue.get("path")));
        dataDictionaryEntry.setHttpMethod(keyValue.get("method"));
        dataDictionaryEntry.setProduces(keyValue.get("produces"));
    }

    private void mergeDataDictionaryTableData() {
        for(Map.Entry<String, Set<FieldAnnotationLineObject>> e : CLASS_FIELD_ANNOTATION.entrySet()) {
            addTableClassFieldEntries(e.getKey(), e.getValue());
        }

        Set<String> classFieldClasses = CLASS_FIELD_ANNOTATION.keySet();
        Set<TableFieldEntry> tableFieldEntries = CLASS_TABLE_ANNOTATION.entrySet().stream()
                .filter(e -> !classFieldClasses.contains(e.getKey()))
                .map(e -> TableFieldEntry.builder().tableName(e.getValue()).build())
                .collect(toSet());
        dataDictionaryEntry.addTableFieldEntries("NoClass", "NoField", tableFieldEntries);
    }

    private void addTableClassFieldEntries(String clazz, Set<FieldAnnotationLineObject> fieldAnnotationLineObjects) {
        for(FieldAnnotationLineObject fa : fieldAnnotationLineObjects) {
            addClassFieldEntry(clazz, fa);
        }
    }

    private void addClassFieldEntry(String clazz, FieldAnnotationLineObject fieldAnnotationLineObject) {
        Map<String, String> parsedAnnotation = parseKeyValueAnnotation(COLUMN_ANN_PATTERN, fieldAnnotationLineObject.getAnnotation());
        ClassFieldEntry classFieldEntry = ClassFieldEntry.builder()
                .fieldName(fieldAnnotationLineObject.getField())
                .fieldType(getClassFieldType(clazz, fieldAnnotationLineObject.getField()).orElse("NotAbleToFindType"))
                .fieldUniqueness(parsedAnnotation.get("unique"))
                .fieldNullable(parsedAnnotation.get("nullable"))
                .fieldUpdatable(parsedAnnotation.get("updatable"))
                .fieldLength(parsedAnnotation.get("length"))
                .fieldPrecision(parsedAnnotation.get("precision"))
                .swaggerEndpointData(getSwaggerEndpointData(dataDictionaryEntry.getHttpMethod(), dataDictionaryEntry.getUri(), fieldAnnotationLineObject.getField()))
                .build();
        dataDictionaryEntry.addClassFieldEntry(clazz, fieldAnnotationLineObject.getField(), classFieldEntry);

        String table = CLASS_TABLE_ANNOTATION.get(clazz);
        String tableFieldName = parsedAnnotation.getOrDefault("value", parsedAnnotation.get("name"));
        addTableFieldEntry(clazz, fieldAnnotationLineObject.getField(), table, tableFieldName);
    }

    private void addTableFieldEntry(String clazz, String field, String table, String tableField) {
        if(TABLE_COLUMNS_DATA.containsKey(table)
                && TABLE_COLUMNS_DATA.get(table).containsKey(tableField)) {
            List<TableColumnsData> tableData = TABLE_COLUMNS_DATA.get(table).get(tableField);
            if(!tableData.isEmpty()) {
                if(tableData.size()>1) {
                    System.out.println(String.format("Warn: Table: [%s] has more than one entry! Number of entries: [%d] - [%s]", table, tableData.size(), tableData));
                }
                TableColumnsData tableColumnsData = tableData.get(0);
                TableFieldEntry.TableFieldEntryBuilder tableFieldEntryBuilder = TableFieldEntry.builder()
                        .tableName(tableColumnsData.getTableName())
                        .fieldName(tableColumnsData.getColumnName())
                        .fieldType(tableColumnsData.getDataType())
                        .fieldPrecision(tableColumnsData.getDataPrecision())
                        .fieldLength(tableColumnsData.getDataPrecision())
                        .fieldNullable(tableColumnsData.getNullable())
                        .columnDataDefault(tableColumnsData.getDataDefault());

                if(CONS_COLUMNS_DATA.containsKey(table)
                        && CONS_COLUMNS_DATA.get(table).containsKey(tableField)) {
                    tableFieldEntryBuilder.columnConstraints(CONS_COLUMNS_DATA.get(table).get(tableField));
                }

                if(INDEX_DATA.containsKey(table)
                        && INDEX_DATA.get(table).containsKey(tableField)) {
                    tableFieldEntryBuilder.columnIndex(INDEX_DATA.get(table).get(tableField));
                }

                dataDictionaryEntry.addTableFieldEntry(clazz, field, tableFieldEntryBuilder.build());
            } else {
                System.out.println(String.format("Warn: Table: [%s] has more than one entry! Number of entries: [%d] - [%s]", table, tableData.size(), tableData));
            }
        }
    }

    public void printDictionary() {
        System.out.println(CSV_HEADER);
        DATA_DIC_ENTRIES.forEach(e ->
                e.getClassTableFields().entrySet()
                        .forEach(te -> {
                                    te.getValue().getValue()
                                            .forEach(ee -> {
                                                Optional<ClassFieldEntry> classFieldEntryOpt = te.getValue().getKey().stream().findAny();

                                                StringBuilder stringBuilder = new StringBuilder()
                                                        .append(addQuotes.apply(e.getHttpMethod())).append(',')
                                                        .append(addQuotes.apply(e.getUri())).append(',')
                                                        .append(addQuotes.apply(e.getProduces())).append(',')
                                                        .append(addClassFieldEntryInfo(classFieldEntryOpt))
                                                        .append(addQuotes.apply(te.getKey().getKey())).append(',')
                                                        .append(addQuotes.apply(te.getKey().getValue())).append(',')
                                                        .append(addQuotes.apply(ee.getTableName())).append(',')
                                                        .append(addQuotes.apply(ee.getFieldName())).append(',')
                                                        .append(addQuotes.apply(isPrimaryKey(ee.getColumnConstraints()).toString())).append(',')
                                                        .append(addQuotes.apply(isForeignKey(ee.getColumnConstraints()).toString())).append(',')
                                                        .append(addQuotes.apply(isUnique(ee.getColumnConstraints()).toString())).append(',')
                                                        .append(addQuotes.apply(ee.getFieldNullable())).append(',')
                                                        .append(addQuotes.apply(ee.getFieldType())).append(',')
                                                        .append(addQuotes.apply(ee.getFieldLength())).append(',')
                                                        .append(addQuotes.apply(ee.getFieldPrecision())).append(',')
                                                        .append(addQuotes.apply(constraintTypeCheck(ee.getColumnConstraints())));

                                                System.out.println(stringBuilder.toString());
                                            });
                        }));
    }

    private StringBuilder addClassFieldEntryInfo(Optional<ClassFieldEntry> classFieldEntryOpt) {
        ClassFieldEntry classFieldEntry = classFieldEntryOpt.orElse(new ClassFieldEntry(null, null, null, null, null, null, null, empty()));
        SwaggerEndpointData swaggerEndpointData = classFieldEntry.getSwaggerEndpointData().orElse(new SwaggerEndpointData(null, null, null, null, null, null, emptyList()));

        return new StringBuilder()
                .append(addQuotes.apply(swaggerEndpointData.getIn())).append(',')
                .append(addQuotes.apply(swaggerEndpointData.getParameterDescription())).append(',')
                .append(addQuotes.apply(swaggerEndpointData.getParameterDefault())).append(',')
                .append(addQuotes.apply(ofNullable(swaggerEndpointData.getEnumValues()).orElse(emptyList()).stream().collect(joining("|")))).append(',')
                .append(addQuotes.apply(swaggerEndpointData.getParameterType())).append(',')
                .append(addQuotes.apply(ofNullable(swaggerEndpointData.getParameterRequired()).map(String::valueOf).orElse(""))).append(',');
    }

    private Boolean isUnique(List<ConstraintColumnsData> constraintColumnsData) {
        return booleanContainsConstraint(constraintColumnsData, ConstraintType.UNIQUE_KEY);
    }

    private Boolean isForeignKey(List<ConstraintColumnsData> constraintColumnsData) {
        return booleanContainsConstraint(constraintColumnsData, ConstraintType.REFERENTIAL);
    }

    private Boolean isPrimaryKey(List<ConstraintColumnsData> constraintColumnsData) {
        return booleanContainsConstraint(constraintColumnsData, ConstraintType.PRIMARY_KEY);
    }

    private boolean booleanContainsConstraint(List<ConstraintColumnsData> constraintColumnsData, ConstraintType constraintType) {
        return streamConstraintsWithType(constraintColumnsData, constraintType)
                .map(ct -> true)
                .findAny()
                .orElse(false);
    }

    private String constraintTypeCheck(List<ConstraintColumnsData> constraintColumnsData) {
        return streamConstraintsWithType(constraintColumnsData, ConstraintType.CHECK)
                .map(c -> new StringBuilder().append(c.getConstraintType())
                            .append(": ")
                            .append(c.getConstraintName())
                            .append('(').append(c.getConstraintSearchCondition()).append(')')
                            .append('[').append(c.getConstraintStatus()).append(']').toString())
                .collect(joining(","));
    }

    private Stream<ConstraintColumnsData> streamConstraintsWithType(List<ConstraintColumnsData> constraintColumnsData, ConstraintType constraintType) {
        return ofNullable(constraintColumnsData).orElse(emptyList())
                .stream()
                .filter(cc -> cc.getConstraintType().equals(constraintType.getConstraintTypeName()));
    }

    private Optional<SwaggerEndpointData> getSwaggerEndpointData(String httpMethod, String endpoint, String fieldName) {
        return ofNullable(swaggerEndpointParser)
                .flatMap(parser -> parser.getSwaggerPropertyInfo(httpMethod, endpoint, fieldName));
    }

    private void clearCurrentRunEntries() {
        CLASS_TABLE_ANNOTATION.clear();
        CLASS_FIELD_ANNOTATION.clear();
    }

    private void addCurrentDataDictionary() {
        DATA_DIC_ENTRIES.add(dataDictionaryEntry);
    }

    private String getTableName(String annotation) {
        Matcher matcher = TABLE_ANN_PATTERN.matcher(annotation);
        if(matcher.matches() && matcher.groupCount() >= 2) {
            return matcher.group(2).split("=")[1];
        }

        System.out.println("Not able to parse Table annotation for: [" + annotation + "]");

        return annotation;
    }

    private Optional<String> getClassFieldType(String clazz, String field) {
        return dataProcessor.fieldTypeLineProcessorData()
                .map(LineParser::lineData)
                .filter(lm -> lm.containsKey(clazz))
                .filter(lm -> lm.get(clazz).containsKey(field))
                .map(lm -> lm.get(clazz).get(field))
                .map(FieldTypeLineObject::getType)
                .map(ft -> ft.substring(ft.lastIndexOf('.')+1));
    }

    private Map<String, String> parseKeyValueAnnotation(Pattern pattern, String annotation) {
        Matcher matcher = pattern.matcher(annotation);

        if(matcher.matches() && matcher.groupCount() >= 2) {
            String annArgs = matcher.group(2);
            return Stream.of(annArgs.split(","))
                    .map(v -> {
                        String[] values = v.split("=");
                        String key = values[0];
                        String value = values[1];

                        int fi = v.indexOf('[');
                        int li = v.lastIndexOf(']');
                        if(fi != -1 && li != -1) {
                            value = v.substring(fi+1, li);
                        }

                        return new SimpleEntry<>(key, value);
            }).collect(toMap(se -> se.getKey(), se -> se.getValue()));
        } else {
            System.out.println("Failed to parse annotation: [" + annotation + "]");
        }

        return new HashMap<String, String>() {{  put("value" , annotation); }};
    }

    public void setDataProcessor(DataProcessor dataProcessor) {
        this.dataProcessor = dataProcessor;
    }

    public void addConstraintColumnsData(Map<String, Map<String, List<ConstraintColumnsData>>> data) {
        this.CONS_COLUMNS_DATA.putAll(data);
    }

    public void addIndexData(Map<String, Map<String, List<IndexData>>> data) {
        this.INDEX_DATA.putAll(data);
    }

    public void addTableColumnsData(Map<String, Map<String, List<TableColumnsData>>> data) {
        this.TABLE_COLUMNS_DATA.putAll(data);
    }

    private boolean hasRequestMapping() {
        return hasRequestMapping;
    }

    private void setHasRequestMapping(boolean hasRequestMapping) {
        this.hasRequestMapping = hasRequestMapping;
    }

    public void setSwaggerEndpointParser(SwaggerEndpointParser swaggerEndpointParser) {
        this.swaggerEndpointParser = swaggerEndpointParser;
    }
}
