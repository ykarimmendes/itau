package br.com.javaparser.methodparser.strategy.impl;

import br.com.javaparser.methodparser.line.vo.MethodLineObject;
import br.com.javaparser.methodparser.strategy.FilterStrategy;

import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class ClassEndsWithFilterStrategy implements FilterStrategy {
    private final String classEndWithPattern;

    public ClassEndsWithFilterStrategy(String classEndWithPattern) {
        this.classEndWithPattern = classEndWithPattern;
    }

    @Override
    public Stream<Map.Entry<String, Map<String, Set<MethodLineObject>>>> filter(Stream<Map.Entry<String, Map<String, Set<MethodLineObject>>>> classMethodEntryStream) {
        return classMethodEntryStream.filter(e -> classFilter().test(e.getKey()));
    }

    public Predicate<String> classFilter() {
        return s -> s.endsWith(classEndWithPattern);
    }
}
