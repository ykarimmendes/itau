package br.com.javaparser.methodparser.line.parser;

import br.com.javaparser.methodparser.line.vo.MethodAnnotationLineObject;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static br.com.javaparser.parser.JavaMethodTreeParser.ANNOTATION_PATTERN_GROUP;
import static br.com.javaparser.parser.JavaMethodTreeParser.CLASS_PATTERN_GROUP;
import static br.com.javaparser.parser.JavaMethodTreeParser.METHOD_PATTERN_GROUP;
import static br.com.javaparser.methodparser.line.vo.LineObjectFactory.newMethodAnnotationLineObject;

public class MethodAnnotationLineParser implements LineParser<Map<String, Map<String, Set<MethodAnnotationLineObject>>>> {

    private static final String METHOD_ANNOTATION_LINE_PATTERN_STR = "(MA):" + CLASS_PATTERN_GROUP + ":" + METHOD_PATTERN_GROUP + " " + ANNOTATION_PATTERN_GROUP;
    private static final Pattern METHOD_ANNOTATION_LINE_PATTERN = Pattern.compile(METHOD_ANNOTATION_LINE_PATTERN_STR);

    private final Map<String, Map<String, Set<MethodAnnotationLineObject>>> METHOD_ANNOTATION_LINE_MAP;

    public MethodAnnotationLineParser() {
        this.METHOD_ANNOTATION_LINE_MAP = new LinkedHashMap<>();
    }

    @Override
    public Pattern linePattern() {
        return METHOD_ANNOTATION_LINE_PATTERN;
    }

    @Override
    public Consumer<Matcher> lineConsumer() {
        return this::consumeMethodAnnotationLine;
    }

    @Override
    public Map<String, Map<String, Set<MethodAnnotationLineObject>>> lineData() {
        return METHOD_ANNOTATION_LINE_MAP;
    }

    private void consumeMethodAnnotationLine(Matcher matcher) {
        MethodAnnotationLineObject methodAnnotationLineObject = newMethodAnnotationLineObject(matcher);
        METHOD_ANNOTATION_LINE_MAP.computeIfAbsent(methodAnnotationLineObject.getOriginClass(), v -> new LinkedHashMap<>())
                .computeIfAbsent(methodAnnotationLineObject.getOriginMethodSignature(), v -> new LinkedHashSet<>()).add(methodAnnotationLineObject);
    }
}
