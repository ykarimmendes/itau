/*
 * Copyright (c) 2011 - Georgios Gousios <gousiosg@gmail.com>
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *
 *     * Redistributions in binary form must reproduce the above
 *       copyright notice, this list of conditions and the following
 *       disclaimer in the documentation and/or other materials provided
 *       with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package br.com.javaparser.analyzer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.bcel.classfile.Constant;
import org.apache.bcel.classfile.ConstantPool;
import org.apache.bcel.classfile.EmptyVisitor;
import org.apache.bcel.classfile.JavaClass;
import org.apache.bcel.classfile.Method;
import org.apache.bcel.generic.ConstantPoolGen;
import org.apache.bcel.generic.MethodGen;

public class ClassVisitor extends EmptyVisitor {

    private JavaClass clazz;
    private ConstantPoolGen constants;
    private String classReferenceFormat;
    private final DynamicCallManager DCManager = new DynamicCallManager();
    private List<String> methodCalls = new ArrayList<>();
    private List<DataDictionary> sqlDictionaryList = new ArrayList<DataDictionary>();
    private Map<String, String> sqlDataDictionary = new LinkedHashMap<>();


    public ClassVisitor(JavaClass jc) {
        clazz = jc;
        constants = new ConstantPoolGen(clazz.getConstantPool());
        classReferenceFormat = "C:" + clazz.getClassName() + " %s";
    }

    public void visitJavaClass(JavaClass jc) {
        jc.getConstantPool().accept(this);

        new AnnotationEntryVisitor(jc).startClass();
        new AttributeVisitor(jc).start();

        startField(jc);
        startMethod(jc);
    }

    public void visitConstantPool(ConstantPool constantPool) {
        for (int i = 0; i < constantPool.getLength(); i++) {
            Constant constant = constantPool.getConstant(i);
            if (constant == null)
                continue;
            if (constant.getTag() == 7) {
                String referencedClass =
                    constantPool.constantToString(constant);
                //sysSystem.out.println(String.format(classReferenceFormat, referencedClass));
            }
        }
    }

    public void startField(JavaClass javaClass) {
        new FieldVisitor(javaClass).start();
    }

    public void startMethod(JavaClass javaClass) {
        Method[] methods = javaClass.getMethods();
        for (int i = 0; i < methods.length; i++) {
            Method method = methods[i];
            DCManager.retrieveCalls(method, javaClass);
            DCManager.linkCalls(method);
            method.accept(this);
            grabSql(javaClass.getClassName(), method);
        }
    }

    public void visitMethod(Method method) {
        new AnnotationEntryVisitor(clazz, method).startMethod();
        MethodGen mg = new MethodGen(method, clazz.getClassName(), constants);
        MethodVisitor visitor = new MethodVisitor(mg, clazz);
        methodCalls.addAll(visitor.start());
    }

    public ClassVisitor start() {
        visitJavaClass(clazz);
        return this;
    }

 public List<String> methodCalls() {
	 final Pattern SQL_TABLE_NAME_PATTERN = Pattern.compile("\\[var=(.\\w*)]", Pattern.MULTILINE);
	 final Pattern ARGUMENT_PATTERN = Pattern.compile("(.*\\()(.*)(\\))", Pattern.MULTILINE);
	 
		for (DataDictionary data : sqlDictionaryList) {
			if(data.getTable().contains("[var=")) {
		        Matcher matcher = SQL_TABLE_NAME_PATTERN.matcher(data.getTable());
		        matcher.matches();
		        String table = matcher.group(1);
				data.setTable(data.getTable().replaceAll("\\[var=.\\w*]", sqlDataDictionary.get(table)));
			}
			for (String s : this.methodCalls) {
				if (!s.contains("table=") && s.contains(data.getMethodNameInClass()) && s.contains(data.getMethodName()) && s.contains(data.getClassName())){
					this.methodCalls.remove(s);
					s = s.replace("java.lang.String", "table="+data.getTable());
					if (!s.contains("table")) {
						Matcher matcher = ARGUMENT_PATTERN.matcher(s);
						matcher.matches();
						s = s.replace(matcher.group(2), "table="+data.getTable());
					} 
					this.methodCalls.add(s);
					break;
				}  
			}
		}
		
		return this.methodCalls;
    	
    }

    public void grabSql(String className, Method method) {
        final Pattern SQL_METHOD_NAME_PATTERN = Pattern.compile("(.*\\p{Punct}+)(?i)(sql|cursoropen|cursorfetch|cursorclose)\\s*\\p{Punct}*.*", Pattern.MULTILINE);
        final Pattern SQL_PATTERN = Pattern.compile("(.*\\p{Punct}+)(cursorClose|cursorFetch|DELETE\\s*FROM|INSERT\\s*INTO|UPDATE|SELECT.*FROM)\\s*(\\w+| ).*", Pattern.MULTILINE);
        try {
            String stringContent = method.getCode().toString();
            Matcher methodMatcher = SQL_METHOD_NAME_PATTERN.matcher(stringContent);
            System.out.println(stringContent);
            // I'll intercept the method byteCode only if it invokes the sql() or cursorOpen() or any other SQL Stmt related handlers
            if (methodMatcher.find()) {
                Matcher sqlTableMatcher = SQL_PATTERN.matcher(stringContent);
                methodMatcher.reset();
                while(sqlTableMatcher.find()) {
                	
                	methodMatcher.find();
	                // In case no matches are found, raises IllegalStateException.
	                // Occurs in cases where we are handling the definition of sql() method itself
                	String table = getTable(methodMatcher.group(2), stringContent,className,sqlTableMatcher.group(3));
	                DataDictionary d = new DataDictionary(className,  method.getName(), table,methodMatcher.group(2) );
	                sqlDictionaryList.add(d);
                }
            }else {
            	System.out.println("grabSql=false");
            }
            
           
        }
        catch (IllegalStateException ex) {
            return;
        }
        catch(NullPointerException ex) {
            return;
        }

    }
    
    private String getTable(String type, String stringContent, String className, String tableName ) {
    	System.out.println("type:"+type);
    	if (!type.contains("cursor")) return tableName;
    	
    	System.out.println("getTable()");
    	System.out.println(stringContent);
        final Pattern VARIABLE_CURSOR_PATTERN = Pattern.compile("(putfield|getfield)\\s*.*\\.(\\w*)\\s*(LnacaLib\\/sqlSupport\\/SQLCursor)", Pattern.MULTILINE);
        Matcher methodMatcher = VARIABLE_CURSOR_PATTERN.matcher(stringContent);
        if(methodMatcher.find()){
        	if (type.contains("cursorOpen")) {
        		sqlDataDictionary.put(methodMatcher.group(2),tableName );
        		System.out.println("sqlDataDictionary:"+methodMatcher.group(2)+","+tableName);
        		return tableName;	
        	}else
        		System.out.println("sqlDataDictionary VAR="+methodMatcher.group(2));
        		return "[var="+methodMatcher.group(2)+"]";
        }
        
        return "";
    	
    }
    
}
