package br.com.javaparser.methodparser.line.parser;

import br.com.javaparser.methodparser.line.vo.ClassAnnotationLineObject;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static br.com.javaparser.parser.JavaMethodTreeParser.ANNOTATION_PATTERN_GROUP;
import static br.com.javaparser.parser.JavaMethodTreeParser.CLASS_PATTERN_GROUP;
import static br.com.javaparser.methodparser.line.vo.LineObjectFactory.newClassAnnotationLineObject;

public class ClassAnnotationLineParser implements LineParser<Map<String, Set<ClassAnnotationLineObject>>> {

    private static final String CLASS_ANNOTATION_LINE_PATTERN_STR = "(CA):" + CLASS_PATTERN_GROUP + " " + ANNOTATION_PATTERN_GROUP;
    private static final Pattern CLASS_ANNOTATION_LINE_PATTERN = Pattern.compile(CLASS_ANNOTATION_LINE_PATTERN_STR);

    private final Map<String, Set<ClassAnnotationLineObject>> CLASS_ANNOTATION_LINE_MAP;

    public ClassAnnotationLineParser() {
        this.CLASS_ANNOTATION_LINE_MAP = new LinkedHashMap<>();
    }

    @Override
    public Pattern linePattern() {
        return CLASS_ANNOTATION_LINE_PATTERN;
    }

    @Override
    public Consumer<Matcher> lineConsumer() {
        return this::consumeClassAnnotationLine;
    }

    @Override
    public Map<String, Set<ClassAnnotationLineObject>> lineData() {
        return CLASS_ANNOTATION_LINE_MAP;
    }

    private void consumeClassAnnotationLine(Matcher matcher) {
        ClassAnnotationLineObject classAnnotationLineObject = newClassAnnotationLineObject(matcher);
        CLASS_ANNOTATION_LINE_MAP.computeIfAbsent(classAnnotationLineObject.getOriginClass(),
                v -> new LinkedHashSet<>()).add(classAnnotationLineObject);
    }
}
