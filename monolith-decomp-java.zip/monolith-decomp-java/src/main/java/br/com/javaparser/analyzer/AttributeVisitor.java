package br.com.javaparser.analyzer;

import edu.umd.cs.findbugs.ba.generic.GenericObjectType;
import edu.umd.cs.findbugs.ba.generic.GenericUtilities;
import org.apache.bcel.classfile.Attribute;
import org.apache.bcel.classfile.EmptyVisitor;
import org.apache.bcel.classfile.JavaClass;
import org.apache.bcel.classfile.Signature;

import java.util.regex.Pattern;

public class AttributeVisitor extends EmptyVisitor {
    private static final Pattern IGNORE_GENERICS_TYPE = Pattern.compile("\\<([A-Z]+:+L[\\p{Graph}]+;)+\\>(L[\\p{Graph}]+)*;*");

    private JavaClass javaClass;

    private final String format;

    public AttributeVisitor(JavaClass javaClass) {
        this.javaClass = javaClass;
        this.format = "GTP:" + javaClass.getClassName() + " %s";
    }

    public void start() {
        for(Attribute attribute : javaClass.getAttributes()) {
            attribute.accept(this);
        }
    }

    public void visitSignature(Signature signature) {
        if(IGNORE_GENERICS_TYPE.matcher(signature.getSignature()).matches()) {
            System.out.println("Ignoring signature: [" + signature.getSignature() + "]");
            return;
        }

        GenericUtilities.getTypeParameters(signature.getSignature())
                .stream()
                .filter(rt -> rt instanceof GenericObjectType)
                .forEach(rt -> {
                    GenericObjectType genericObjectType = (GenericObjectType) rt;
                    genericObjectType.getParameters()
                            .forEach(p -> System.out.println(String.format(format, p.toString())));
                });
    }
}
