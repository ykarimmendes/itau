package br.com.javaparser.methodparser.strategy.impl;

import java.io.IOException;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

import static java.nio.file.Files.readAllLines;
import static java.util.stream.Collectors.toList;

public class ClassAndMethodFileDecoratorFilterStrategy extends ClassAndMethodFilterStrategy {

    private static final String SEP = ";";

    private final Path classMethodsFile;
    private final String separator;
    private final int numberOfValues;

    public ClassAndMethodFileDecoratorFilterStrategy(Path classMethodsFile, String separator, int numberOfValues, boolean debug) {
        this.classMethodsFile = classMethodsFile;
        this.separator = separator;
        this.numberOfValues = numberOfValues;
        this.classMethods = loadFile(classMethodsFile);

        if(debug) {
        classMethods.stream().forEach(m -> {
                m.entrySet().forEach(e -> {
                    System.out.println("Entry: [" + e.getKey() + "] -> v: [" + e.getValue() + "]");
                });
            });
        }
    }

    public ClassAndMethodFileDecoratorFilterStrategy(Path classMethodsFile, int numberOfValues) {
        this(classMethodsFile, SEP, numberOfValues, false);
    }

    private List<Map<String, Set<String>>> loadFile(Path classMethodsFile) {
        return readFileLines(classMethodsFile)
                .map(l -> l.split(separator))
                .filter(sa -> sa.length >= numberOfValues)
                .map(this::stringArrayToMap).collect(toList());
    }

    private Stream<String> readFileLines(Path classMethodsFile) {
        try {
            return readAllLines(classMethodsFile).stream();
        } catch (IOException e) {
            throw new IllegalStateException(String.format("Failed to read file: [%s]", classMethodsFile));
        }
    }

    private Map<String, Set<String>> stringArrayToMap(String[] stringArray) {
        Map<String, Set<String>> hashMap = new LinkedHashMap<>();
        hashMap.computeIfAbsent(stringArray[2], v -> new LinkedHashSet<>()).add(stringArray[3]);

        return hashMap;
    }
}