package br.com.javaparser.methodparser.line.parser;

import br.com.javaparser.methodparser.line.vo.MethodLineObject;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static br.com.javaparser.parser.JavaMethodTreeParser.CLASS_PATTERN_GROUP;
import static br.com.javaparser.parser.JavaMethodTreeParser.METHOD_PATTERN_GROUP;
import static br.com.javaparser.methodparser.line.vo.LineObjectFactory.newMethodLineObject;

public class MethodLineParser implements LineParser<Map<String, Map<String, Set<MethodLineObject>>>> {

    private static final String METHOD_LINE_PATTERN_STR = "(M):" + CLASS_PATTERN_GROUP + ":" + METHOD_PATTERN_GROUP
            + " \\(([A-Z])\\)" +CLASS_PATTERN_GROUP + ":" + METHOD_PATTERN_GROUP;
    private static final Pattern METHOD_LINE_PATTERN = Pattern.compile(METHOD_LINE_PATTERN_STR);

    private final Map<String, Map<String, Set<MethodLineObject>>> METHOD_LINE_MAP;

    public MethodLineParser() {
        this.METHOD_LINE_MAP = new LinkedHashMap<>();
    }

    @Override
    public Pattern linePattern() {
        return METHOD_LINE_PATTERN;
    }

    @Override
    public Consumer<Matcher> lineConsumer() {
        return this::consumeMethodLine;
    }

    @Override
    public Map<String, Map<String, Set<MethodLineObject>>> lineData() {
        return METHOD_LINE_MAP;
    }

    private void consumeMethodLine(Matcher matcher) {
        MethodLineObject lineObject = newMethodLineObject(matcher);

        METHOD_LINE_MAP.computeIfAbsent(lineObject.getOriginClass(), v -> new LinkedHashMap<>())
                .computeIfAbsent(lineObject.getOriginMethodSignature(), v -> new LinkedHashSet<>()).add(lineObject);
    }
}
