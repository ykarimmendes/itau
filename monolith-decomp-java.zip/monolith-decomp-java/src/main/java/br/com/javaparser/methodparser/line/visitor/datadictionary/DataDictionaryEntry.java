package br.com.javaparser.methodparser.line.visitor.datadictionary;

import br.com.sqlparser.ConstraintColumnsData;
import br.com.sqlparser.IndexData;
import br.com.swaggerparser.SwaggerEndpointData;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.AbstractMap.SimpleEntry;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DataDictionaryEntry {

    private boolean closed = false;
    private String uri;
    private String httpMethod;
    private String produces;

    @Builder.Default
    private Map<SimpleEntry<String, String>, SimpleEntry<Set<ClassFieldEntry>, Set<TableFieldEntry>>> classTableFields = new HashMap<>();

    public void addClassFieldEntry(String clazz, String classField, ClassFieldEntry classFieldEntry) {
        this.classTableFields.computeIfAbsent(new SimpleEntry<>(clazz, classField),
                v -> new SimpleEntry<>(new HashSet<>(), new HashSet<>())).getKey().add(classFieldEntry);
    }

    public void addClassFieldEntries(String clazz, String classField, Set<ClassFieldEntry> classFieldEntries) {
        this.classTableFields.computeIfAbsent(new SimpleEntry<>(clazz, classField),
                v -> new SimpleEntry<>(new HashSet<>(), new HashSet<>())).getKey().addAll(classFieldEntries);
    }

    public void addTableFieldEntry(String clazz, String classField, TableFieldEntry tableFieldEntry) {
        this.classTableFields.computeIfAbsent(new SimpleEntry<>(clazz, classField),
                v -> new SimpleEntry<>(new HashSet<>(), new HashSet<>())).getValue().add(tableFieldEntry);
    }

    public void addTableFieldEntries(String clazz, String classField, Set<TableFieldEntry> tableFieldEntries) {
        this.classTableFields.computeIfAbsent(new SimpleEntry<>(clazz, classField),
                v -> new SimpleEntry<>(new HashSet<>(), new HashSet<>())).getValue().addAll(tableFieldEntries);
    }

    @Getter
    @AllArgsConstructor
    public static class FieldEntry {
        private String fieldName;
        private String fieldType;
        private String fieldUniqueness;
        private String fieldNullable;
        private String fieldLength;
        private String fieldPrecision;
    }

    @ToString
    @Getter
    public static  class ClassFieldEntry extends FieldEntry {
        private String fieldUpdatable;
        private Optional<SwaggerEndpointData> swaggerEndpointData;

        @Builder
        public ClassFieldEntry(String fieldName, String fieldType, String fieldUniqueness, String fieldNullable, String fieldLength, String fieldPrecision, String fieldUpdatable, Optional<SwaggerEndpointData> swaggerEndpointData) {
            super(fieldName, fieldType, fieldUniqueness, fieldNullable, fieldLength, fieldPrecision);
            this.fieldUpdatable = fieldUpdatable;
            this.swaggerEndpointData = swaggerEndpointData;
        }
    }

    @ToString
    @Getter
    public static class TableFieldEntry extends FieldEntry {
        private String tableName;
        private String columnDataDefault;
        private List<ConstraintColumnsData> columnConstraints;
        private List<IndexData> columnIndex;

        @Builder
        public TableFieldEntry(String tableName, String fieldName, String fieldType, String fieldUniqueness, String fieldNullable, String fieldLength, String fieldPrecision, String columnDataDefault, List<ConstraintColumnsData> columnConstraints, List<IndexData> columnIndex) {
            super(fieldName, fieldType, fieldUniqueness, fieldNullable, fieldLength, fieldPrecision);
            this.tableName = tableName;
            this.columnDataDefault = columnDataDefault;
            this.columnConstraints = columnConstraints;
            this.columnIndex = columnIndex;
        }
    }

    public enum ConstraintType {
        CHECK("Check"),
        PRIMARY_KEY("Primary Key"),
        REFERENTIAL("Referential"),
        READ_ONLY_ON_VIEW("Read Only On View"),
        UNIQUE_KEY("Unique Key"),
        CHECK_ON_VIEW("Check On View");

        private final String constraintTypeName;

        ConstraintType(String constraintTypeName) {
            this.constraintTypeName = constraintTypeName;
        }

        public String getConstraintTypeName() {
            return constraintTypeName;
        }
    }
}
