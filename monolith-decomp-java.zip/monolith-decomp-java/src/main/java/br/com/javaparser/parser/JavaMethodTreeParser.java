package br.com.javaparser.parser;

import br.com.javaparser.methodparser.line.vo.ClassAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.ClassGenericLineObject;
import br.com.javaparser.methodparser.line.vo.FieldAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.FieldTypeLineObject;
import br.com.javaparser.methodparser.line.vo.MethodAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.MethodLineObject;
import br.com.javaparser.methodparser.line.processor.DataProcessor;
import br.com.javaparser.methodparser.line.visitor.LineObjectVisitor;
import br.com.javaparser.methodparser.line.parser.LineParser;
import br.com.javaparser.methodparser.repo.ClassRepository;
import br.com.javaparser.methodparser.strategy.FilterContext;

import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import static br.com.javaparser.methodparser.line.vo.LineObjectFactory.newInternalMethodLineObject;
import static br.com.javaparser.methodparser.line.vo.LineObjectFactory.newMethodLineObject;
import static java.lang.Character.toLowerCase;
import static java.nio.file.Files.readAllLines;
import static java.util.Optional.ofNullable;
import static java.util.regex.Pattern.compile;
import static java.util.regex.Pattern.quote;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toSet;

public class JavaMethodTreeParser {
    public static final String CLASS_PATTERN_GROUP = "([\\p{Alnum}\\p{Punct}]+)";
    public static final String METHOD_PATTERN_GROUP = "([\\p{Alnum}\\p{Punct}]+)";
    public static final String ANNOTATION_PATTERN_GROUP = "([\\p{Alnum}\\p{Punct}\\p{Blank}]+)";
    public static final String FIELD_ANNOTATION_PATTERN_GROUP = "([\\p{Alnum}]+)";
    public static final String FIELD_NAME_PATTERN_GROUP = "([\\p{Alnum}]+)";

    private static final Pattern METHOD_SIGNATURE_PATTERN = compile("([a-zA-Z0-9\\<\\>]+)(\\([a-zA-Z0-9.,\\$]*\\))");
    private static final Pattern GETSET_METHOD_SIGNATURE_PATTERN = compile("(get|set|is)([a-zA-Z0-9\\<\\>]+)(\\([a-zA-Z0-9.,\\$]*\\))");

    private Map<Pattern, Consumer<Matcher>> PATTERN_CONSUMER_MAP = new LinkedHashMap<>(3);

    private boolean isDebug = false;
    private final Set<String> alternateClassImplNameFormats;

    private Map<String, Map<String, Set<MethodLineObject>>> METHOD_LINE_MAP;
    private Map<String, Set<ClassAnnotationLineObject>> CLASS_ANNOTATION_LINE_MAP;
    private Map<String, Map<String, Set<MethodAnnotationLineObject>>> METHOD_ANNOTATION_LINE_MAP;
    private Map<String, Set<ClassGenericLineObject>> CLASS_GENERIC_LINE_MAP;
    private Map<String, Map<String, Set<FieldAnnotationLineObject>>> FIELD_ANNOTATION_LINE_MAP;
    private Map<String, Map<String, FieldTypeLineObject>> FIELD_TYPE_LINE_MAP;

    private final ClassRepository classRepository;

    private LineObjectVisitor lineObjectVisitor;

    public JavaMethodTreeParser() {
        this.alternateClassImplNameFormats = new HashSet<>();
        this.classRepository = new ClassRepository();
    }

    private void addPatternConsumerMap(DataProcessor dataProcessor) {
        dataProcessor.methodLineProcessor()
                .ifPresent(lp -> PATTERN_CONSUMER_MAP.put(lp.linePattern(), lp.lineConsumer()));
        dataProcessor.classAnnotationLineProcessorData()
                .ifPresent(lp -> PATTERN_CONSUMER_MAP.put(lp.linePattern(), lp.lineConsumer()));
        dataProcessor.methodAnnotationLineProcessorData()
                .ifPresent(lp -> PATTERN_CONSUMER_MAP.put(lp.linePattern(), lp.lineConsumer()));
        dataProcessor.classGenericLineProcessorData()
                .ifPresent(lp -> PATTERN_CONSUMER_MAP.put(lp.linePattern(), lp.lineConsumer()));
        dataProcessor.fieldAnnotationLineProcessorData()
                .ifPresent(lp -> PATTERN_CONSUMER_MAP.put(lp.linePattern(), lp.lineConsumer()));
        dataProcessor.fieldTypeLineProcessorData()
                .ifPresent(lp -> PATTERN_CONSUMER_MAP.put(lp.linePattern(), lp.lineConsumer()));
    }

    public void loadParseFile(Path path, DataProcessor dataProcessor) throws IOException {
        List<String> fileLines = readAllLines(path);
        addPatternConsumerMap(dataProcessor);

        for(String line : fileLines) {
            consumeFileLine(line);
        }

        METHOD_LINE_MAP = dataProcessor.methodLineProcessor()
                .map(LineParser::lineData).orElseGet(HashMap::new);
        CLASS_ANNOTATION_LINE_MAP = dataProcessor.classAnnotationLineProcessorData()
                .map(LineParser::lineData).orElseGet(HashMap::new);
        METHOD_ANNOTATION_LINE_MAP = dataProcessor.methodAnnotationLineProcessorData()
                .map(LineParser::lineData).orElseGet(HashMap::new);
        CLASS_GENERIC_LINE_MAP = dataProcessor.classGenericLineProcessorData()
                .map(LineParser::lineData).orElseGet(HashMap::new);
        FIELD_ANNOTATION_LINE_MAP = dataProcessor.fieldAnnotationLineProcessorData()
                .map(LineParser::lineData).orElseGet(HashMap::new);
        FIELD_TYPE_LINE_MAP = dataProcessor.fieldTypeLineProcessorData()
                .map(LineParser::lineData).orElseGet(HashMap::new);
    }

    public void visit(LineObjectVisitor lineObjectVisitor, FilterContext filterContext) {
        this.lineObjectVisitor = lineObjectVisitor;
        filterContext.classFilter(METHOD_LINE_MAP.entrySet().stream())
                .forEach(entry -> handleClassMethods(entry.getKey(), entry.getValue(), 0));
    }

    private void handleClassMethods(String clazz, Map<String, Set<MethodLineObject>> methods, int level) {
        lineObjectVisitor.startTopClassVisit(0, clazz);
        handleClassAnnotationLine(clazz, 0);
        level += 2;
        int nlevel = level;
        methods.entrySet().stream()
                .forEach(entry -> {
                    if(!entry.getKey().contains("lambda$")) {
                        lineObjectVisitor.startTopMethodVisit(nlevel, clazz, entry.getKey());
                        handleMethodCalls(METHOD_LINE_MAP, newInternalMethodLineObject(clazz, entry.getKey()), ofNullable(entry.getValue()), nlevel);
                        lineObjectVisitor.endTopMethodVisit(nlevel, clazz, entry.getKey());
                    }
                });

        lineObjectVisitor.endTopClassVisit((level-2), clazz);
    }

    private void handleMethodCalls(Map<String, Map<String, Set<MethodLineObject>>> fileObject, MethodLineObject methodLineObject, Optional<Set<MethodLineObject>> lineObjectsOpt, int level) {
        handleMethodLineObject(methodLineObject, level);

        if(!lineObjectsOpt.isPresent()) {
            return;
        }

        level = level + 2;
        for(MethodLineObject lineObject : lineObjectsOpt.get()) {
            int nlevel = level;

            if(methodLineObject.getDestMethodSignature().contains("getWrapped")) {
                return;
            }

            streamToClassesOrInterfaces(fileObject, lineObject.getDestClass())
                    .forEach(classOrInterface -> {
                        if(fileObject.containsKey(classOrInterface)) {
                            deriveMethodNames(lineObject, ofNullable(fileObject.get(classOrInterface)));

                            MethodLineObject methodLineObject1 = newMethodLineObject(classOrInterface, lineObject);
                            handleMethodCalls(fileObject, methodLineObject1,
                                    ofNullable(fileObject.get(classOrInterface))
                                            .map(m -> m.get(lineObject.getDestMethodSignature())), nlevel);
                        } else {
                            handleMethodLineObject(lineObject, nlevel);
                        }
                    });
        }
    }

    private void handleMethodLineObject(MethodLineObject methodLineObject, int level) {
        lineObjectVisitor.visit(level, methodLineObject);
        handleMethodAnnotationLine(methodLineObject.getDestClass(), methodLineObject.getDestMethodSignature(), level);
        handleClassGenericsLine(methodLineObject.getDestClass(), level);
        handleFieldAnnotationLine(methodLineObject.getDestClass(), methodLineObject.getDestMethodSignature(), level);
    }

    private void handleClassGenericsLine(String clazz, int level) {
        Consumer<String> classesConsumer = c -> {
                    if(CLASS_GENERIC_LINE_MAP.containsKey(c)) {
                        int nlevel = level + 1;
                        for(ClassGenericLineObject classGenericLineObject : CLASS_GENERIC_LINE_MAP.get(c)) {
                            if(CLASS_ANNOTATION_LINE_MAP.containsKey(classGenericLineObject.getGeneric())) {
                                CLASS_ANNOTATION_LINE_MAP.get(classGenericLineObject.getGeneric())
                                        .forEach(ca -> lineObjectVisitor.visit(nlevel, c, classGenericLineObject, ca));
                            }
                        }
                    }
                };

        doForAllDerivedClasses(clazz, classesConsumer);
    }

    private void handleClassAnnotationLine(String clazz, int level) {
        Consumer<String> classesConsumer = c -> {
            if(CLASS_ANNOTATION_LINE_MAP.containsKey(c)) {
                int nlevel = level + 1;
                CLASS_ANNOTATION_LINE_MAP.get(c)
                        .forEach(ca -> lineObjectVisitor.visit(nlevel, ca));
            }};

        doForAllDerivedClasses(clazz, classesConsumer);
    }

    private void handleFieldAnnotationLine(String clazz, String method, int level) {
        Matcher baseMethodMatcher = GETSET_METHOD_SIGNATURE_PATTERN.matcher(method);
        if(FIELD_ANNOTATION_LINE_MAP.containsKey(clazz) && baseMethodMatcher.matches()) {
            String fieldName = decapitalizeInitial(baseMethodMatcher.group(2));

            if(FIELD_ANNOTATION_LINE_MAP.get(clazz).containsKey(fieldName)) {
                int nlevel = level + 1;
                FIELD_ANNOTATION_LINE_MAP.get(clazz).get(fieldName)
                        .forEach(field -> lineObjectVisitor.visit(nlevel, clazz, method, field));
            }
        }
    }

    private void doForAllDerivedClasses(String baseClass, Consumer<String> classesConsumer) {
        streamToClassesOrInterfaces(METHOD_LINE_MAP, baseClass)
                .forEach(classesConsumer);
    }

    private void handleMethodAnnotationLine(String clazz, String method, int level) {
        streamToClassesOrInterfaces(METHOD_LINE_MAP, clazz)
            .forEach(c -> {
                if(METHOD_ANNOTATION_LINE_MAP.containsKey(c) && METHOD_ANNOTATION_LINE_MAP.get(c).containsKey(method)) {
                    int nlevel = level + 1;
                    METHOD_ANNOTATION_LINE_MAP.get(c).get(method)
                            .forEach(ma -> lineObjectVisitor.visit(nlevel, c, method, ma));
                }
            });
    }

    private Stream<String> streamToClassesOrInterfaces(Map<String, Map<String, Set<MethodLineObject>>> fileObject, String destClass) {
        if(!classRepository.contains(destClass)) {
            Set<String> classesInterfaces = fileObject.entrySet().stream()
                    .filter(e -> possibleClassesImplPatterns(destClass)
                            .filter(p -> compile(quote(p))
                                    .matcher(e.getKey()).matches()).findAny().isPresent())
                    .map(Map.Entry::getKey)
                     .collect(toSet());

            Set<String> classesOrdered = new LinkedHashSet<>(classesInterfaces.size()+1);
            classesOrdered.add(destClass);
            classesOrdered.addAll(classesInterfaces);
            classesOrdered.forEach(ci -> classRepository.add(ci, classesOrdered));
        }

        return classRepository.get(destClass)
                .stream().sorted();
    }

    private Stream<String> possibleClassesImplPatterns(String baseClass) {
        return Stream.concat(Stream.of(baseClass),
                alternateClassImplNameFormats.stream().map(fmt -> String.format(fmt, baseClass)))
                .flatMap(cn -> Stream.of(cn, cn + "\\$*[0-9]*"));
    }

    private void deriveMethodNames(MethodLineObject methodLineObject, Optional<Map<String, Set<MethodLineObject>>> methodsAndCallsOpt) {
        if(!methodsAndCallsOpt.isPresent()) {
            return;
        }

        Matcher baseMethodMatcher = METHOD_SIGNATURE_PATTERN.matcher(methodLineObject.getDestMethodSignature());
        if(baseMethodMatcher.matches()) {
            String methodName = baseMethodMatcher.group(1);
            String methodArgs = baseMethodMatcher.group(2);
            Pattern methodNamePattern = compile("([a-zA-Z0-9]+)\\$(" + methodName + ")\\$([0-9]+)(" + METHOD_PATTERN_GROUP + ")");
            List<Map.Entry<String, Set<MethodLineObject>>> entries = methodsAndCallsOpt.get().entrySet().stream()
                    .filter(e -> methodNamePattern.matcher(e.getKey()).matches())
                    .collect(toList());

            for(Map.Entry<String, Set<MethodLineObject>> relatedMethodAndCalls : entries) {
                Matcher methodMatcher = methodNamePattern.matcher(relatedMethodAndCalls.getKey());
                if(methodMatcher.matches()
                        && (methodArgs.equals(methodMatcher.group(4))
                            || methodLineObject.getDestType().equals("I"))) {
                    Set<MethodLineObject> currentMethodCalls = methodsAndCallsOpt.get().get(methodLineObject.getDestMethodSignature());
                    currentMethodCalls.addAll(relatedMethodAndCalls.getValue());
                }
            }
        }
    }

    private String decapitalizeInitial(String str) {
        char c[] = str.toCharArray();
        c[0] = toLowerCase(c[0]);
         return new String(c);
    }

    private void consumeFileLine(String line) {
        boolean matched = false;
        for(Map.Entry<Pattern, Consumer<Matcher>> entry : PATTERN_CONSUMER_MAP.entrySet()) {
            Matcher matcher = entry.getKey().matcher(line);
            if(matcher.matches()) {
                matched = true;
                entry.getValue().accept(matcher);
                break;
            }
        }

        if(isDebug && !matched) {
            System.out.println("Line not matched: [" + line + "]");
        }
    }

    private void printGroups(String desc, Matcher matcher) {
        System.out.println(desc);
        for(int i=1; i<=matcher.groupCount(); i++) {
            System.out.println("  Group: [" + i + "] -> [" + matcher.group(i) + "]");
        }
    }

    public void addAlternateClassImplNameFormat(String alternateClassImplNameFormat) {
        alternateClassImplNameFormats.add(alternateClassImplNameFormat);
    }

    public void debugEnabled(boolean isDebug) {
        this.isDebug = isDebug;
    }
}
