package br.com.javaparser.methodparser.line.vo;

import java.util.regex.Matcher;

public class LineObjectFactory {
    public static MethodLineObject newMethodLineObject(Matcher matcher) {
        return new MethodLineObject(matcher.group(1), matcher.group(2), matcher.group(3),
                matcher.group(4), matcher.group(5), matcher.group(6));
    }

    public static MethodLineObject newMethodLineObject(String newDestClass, MethodLineObject methodLineObject) {
        return new MethodLineObject(newDestClass, methodLineObject);
    }

    public static MethodLineObject newInternalMethodLineObject(String destClass, String destMethod) {
        return new MethodLineObject("Internal", destClass, destMethod);
    }

    public static ClassAnnotationLineObject newClassAnnotationLineObject(Matcher matcher) {
        return new ClassAnnotationLineObject(matcher.group(1), matcher.group(2), matcher.group(3));
    }

    public static MethodAnnotationLineObject newMethodAnnotationLineObject(Matcher matcher) {
        return new MethodAnnotationLineObject(matcher.group(1), matcher.group(2), matcher.group(3), matcher.group(4));
    }

    public static FieldAnnotationLineObject newFieldAnnotationLineObject(Matcher matcher) {
        return new FieldAnnotationLineObject(matcher.group(1), matcher.group(2), matcher.group(3), matcher.group(4));
    }

    public static ClassGenericLineObject newClassGenericLineObject(Matcher matcher) {
        return new ClassGenericLineObject(matcher.group(1), matcher.group(2), matcher.group(3));
    }

    public static ClassLineObject newClassLineObject(Matcher matcher) {
        return new ClassLineObject(matcher.group(1), matcher.group(2), matcher.group(3));
    }

    public static FieldTypeLineObject newFieldTypeLineObject(Matcher matcher) {
        return new FieldTypeLineObject(matcher.group(1), matcher.group(2), matcher.group(3), matcher.group(4));
    }
}
