package br.com.javaparser.analyzer;

import org.apache.bcel.classfile.AnnotationEntry;
import org.apache.bcel.classfile.ArrayElementValue;
import org.apache.bcel.classfile.ClassElementValue;
import org.apache.bcel.classfile.ElementValue;
import org.apache.bcel.classfile.ElementValuePair;
import org.apache.bcel.classfile.EmptyVisitor;
import org.apache.bcel.classfile.Field;
import org.apache.bcel.classfile.JavaClass;
import org.apache.bcel.classfile.Method;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class AnnotationEntryVisitor extends EmptyVisitor {

    private String printFormat;
    private JavaClass javaClass;
    private Method method;
    private Field field;

    public AnnotationEntryVisitor(JavaClass javaClass, Method method, Field field) {
        this.javaClass = javaClass;
        this.method = method;
        this.field = field;
    }

    public AnnotationEntryVisitor(JavaClass javaClass, Field field) {
        this(javaClass, null, field);
        printFormat = "FA:" + javaClass.getClassName() + ":"
                + field.getName() + " %s";
    }

    public AnnotationEntryVisitor(JavaClass javaClass, Method method) {
        this(javaClass, method, null);
        printFormat = "MA:" + javaClass.getClassName() + ":" + MethodVisitor.ppMethodSignature(method.getName(), method.getArgumentTypes()) + " %s";
    }

    public AnnotationEntryVisitor(JavaClass javaClass) {
        this(javaClass, null, null);
        printFormat = "CA:" + javaClass.getClassName() + " %s";
    }

    public void startClass() {
        for(AnnotationEntry annotationEntry : javaClass.getAnnotationEntries()) {
            annotationEntry.accept(this);
        }
    }

    public void startMethod() {
        for(AnnotationEntry annotationEntry : method.getAnnotationEntries()) {
            annotationEntry.accept(this);
        }
    }

    public void startField() {
        for(AnnotationEntry annotationEntry : field.getAnnotationEntries()) {
            annotationEntry.accept(this);
        }
    }

    public void visitAnnotationEntry(AnnotationEntry annotationEntry) {
        ppAnnotation(annotationEntry);
    }

    private void ppAnnotation(AnnotationEntry annotationEntry) {
        String anno = String.format(printFormat, parseAnnotation(annotationEntry));
        System.out.println(anno);
    }

    private String parseAnnotation(AnnotationEntry annotationEntry) {
        String annotationType = ppClass(annotationEntry.getAnnotationType());

        String annotationArgs = Stream.of(annotationEntry.getElementValuePairs())
                .map(this::ppElementValuePair)
                .collect(Collectors.joining(","));

        return annotationType + "(" + annotationArgs + ")";
    }

    private String ppElementValuePair(ElementValuePair elementValuePair) {
        ElementValue elementValue = elementValuePair.getValue();
        String elements;
        if(elementValue instanceof ArrayElementValue) {
            ArrayElementValue arrayElementValue = (ArrayElementValue) elementValue;
            elements = Stream.of(arrayElementValue.getElementValuesArray())
                    .map(this::ppElementValue)
                    .collect(Collectors.joining(",", "[", "]"));
        } else if(elementValue instanceof ClassElementValue) {
            elements = ppClass(elementValue.stringifyValue());
        } else {
            elements = elementValue.stringifyValue();
        }

        return elementValuePair.getNameString() + "=" + elements;
    }

    private String ppElementValue(ElementValue elementValue) {
        if(elementValue instanceof ClassElementValue) {
            return ppClass(elementValue.stringifyValue());
        }

        return elementValue.stringifyValue();
    }

    private String ppClass(String clazz) {
        return clazz.replaceAll("^L", "")
                .replaceAll(";", "")
                .replaceAll("/", ".");
    }
}
