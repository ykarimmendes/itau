package br.com.javaparser.methodparser.repo;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class ClassRepository {
    private final Map<String, Set<String>> CLASS_DATA;

    public ClassRepository() {
        this.CLASS_DATA = new HashMap<>();
    }

    public void add(String key, Set<String> value) {
        CLASS_DATA.computeIfAbsent(key, v -> new HashSet<>()).addAll(value);
    }

    public Set<String> get(String key) {
        return CLASS_DATA.get(key);
    }

    public boolean contains(String key) {
        return CLASS_DATA.containsKey(key);
    }
}
