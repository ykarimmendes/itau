package br.com.javaparser.methodparser.line.vo;

import lombok.Data;

@Data
public class ClassGenericLineObject extends LineObject {
    private String generic;

    public ClassGenericLineObject(String originType, String originClass, String generic) {
        super(originType, originClass);
        this.generic = generic;
    }
}
