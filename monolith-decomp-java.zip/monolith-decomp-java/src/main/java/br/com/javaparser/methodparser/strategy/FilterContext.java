package br.com.javaparser.methodparser.strategy;

import br.com.javaparser.methodparser.line.vo.MethodLineObject;

import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

public class FilterContext {
    private final FilterStrategy filterStrategy;

    public FilterContext(FilterStrategy filterStrategy) {
        this.filterStrategy = filterStrategy;
    }

    public Stream<Map.Entry<String, Map<String, Set<MethodLineObject>>>> classFilter(Stream<Map.Entry<String, Map<String, Set<MethodLineObject>>>> classMethodEntryStream) {
        return filterStrategy.filter(classMethodEntryStream);
    }
}
