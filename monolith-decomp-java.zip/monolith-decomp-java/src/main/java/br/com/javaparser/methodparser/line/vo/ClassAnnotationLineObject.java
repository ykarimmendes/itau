package br.com.javaparser.methodparser.line.vo;

import lombok.Data;

@Data
public class ClassAnnotationLineObject extends LineObject {
    private String annotation;

    public ClassAnnotationLineObject(String originType, String originClass, String annotation) {
        super(originType, originClass);
        this.annotation = annotation;
    }
}
