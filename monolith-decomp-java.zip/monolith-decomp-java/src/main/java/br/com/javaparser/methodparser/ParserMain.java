package br.com.javaparser.methodparser;

import br.com.javaparser.parser.run.ParserRun;
import br.com.javaparser.parser.run.RunDataDictionary;
import br.com.javaparser.parser.run.RunSysOut;
import br.com.javaparser.methodparser.strategy.FilterContext;
import br.com.javaparser.methodparser.strategy.FilterStrategy;
import br.com.javaparser.methodparser.strategy.impl.ClassEndsWithFilterStrategy;

import java.nio.file.Path;
import java.nio.file.Paths;

public class ParserMain {
    public static void main(String[] args) throws Exception {
    	//args = new String[2];
    	//args[0] = "1";
    	//args[1] = "C:\\temp\\analysis-javacourse.txt";
        if(args.length < 2) {
            System.err.println("Error Specify: arg1: type[1 or 2] arg2: analysis file");
            System.exit(1);
        }

        Integer type = Integer.valueOf(args[0]);
        Path path = Paths.get(args[1]);
        FilterStrategy classStrategy = new ClassEndsWithFilterStrategy("");

        ParserRun parserRun = null;
        if(type.equals(1)) {
            parserRun = new RunSysOut();
        } else if(type.equals(2)) {
            parserRun = new RunDataDictionary();
        } else {
            System.err.println("Type must be 1 or 2");
            System.exit(1);
        }

        parserRun.run(path, new FilterContext(classStrategy));
    }
}
