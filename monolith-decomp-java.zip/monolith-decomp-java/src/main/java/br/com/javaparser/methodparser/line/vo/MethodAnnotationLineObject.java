package br.com.javaparser.methodparser.line.vo;

import lombok.Data;

@Data
public class MethodAnnotationLineObject extends LineObject {
    private String annotation;

    public MethodAnnotationLineObject(String originType, String originClass, String originMethodSignature, String annotation) {
        super(originType, originClass, originMethodSignature);
        this.annotation = annotation;
    }
}
