package br.com.javaparser.methodparser.line.vo;

import lombok.Data;

@Data
public class FieldAnnotationLineObject extends LineObject {
    private String field;
    private String annotation;

    public FieldAnnotationLineObject(String originType, String originClass, String field, String annotation) {
        super(originType, originClass);
        this.field = field;
        this.annotation = annotation;
    }
}
