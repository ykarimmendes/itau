package br.com.javaparser.methodparser.line.processor;

import br.com.javaparser.methodparser.line.vo.ClassAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.ClassGenericLineObject;
import br.com.javaparser.methodparser.line.vo.FieldAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.FieldTypeLineObject;
import br.com.javaparser.methodparser.line.vo.MethodAnnotationLineObject;
import br.com.javaparser.methodparser.line.vo.MethodLineObject;
import br.com.javaparser.methodparser.line.parser.LineParser;

import java.util.Map;
import java.util.Optional;
import java.util.Set;

public class EmptyDataProcessor implements DataProcessor {
    @Override
    public Optional<LineParser<Map<String, Map<String, Set<MethodLineObject>>>>> methodLineProcessor() {
        return Optional.empty();
    }

    @Override
    public Optional<LineParser<Map<String, Set<ClassAnnotationLineObject>>>> classAnnotationLineProcessorData() {
        return Optional.empty();
    }

    @Override
    public Optional<LineParser<Map<String, Map<String, Set<MethodAnnotationLineObject>>>>> methodAnnotationLineProcessorData() {
        return Optional.empty();
    }

    @Override
    public Optional<LineParser<Map<String, Set<ClassGenericLineObject>>>> classGenericLineProcessorData() {
        return Optional.empty();
    }

    @Override
    public Optional<LineParser<Map<String, Map<String, Set<FieldAnnotationLineObject>>>>> fieldAnnotationLineProcessorData() {
        return Optional.empty();
    }

    @Override
    public Optional<LineParser<Map<String, Map<String, FieldTypeLineObject>>>> fieldTypeLineProcessorData() {
        return Optional.empty();
    }
}
