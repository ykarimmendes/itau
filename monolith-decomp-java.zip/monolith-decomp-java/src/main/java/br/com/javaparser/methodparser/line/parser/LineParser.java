package br.com.javaparser.methodparser.line.parser;

import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public interface LineParser<R> {
    Pattern linePattern();
    Consumer<Matcher> lineConsumer();
    R lineData();

    default void dump() {
    }
}
