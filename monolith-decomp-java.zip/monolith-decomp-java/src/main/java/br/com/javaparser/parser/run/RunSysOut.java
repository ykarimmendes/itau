package br.com.javaparser.parser.run;

import br.com.javaparser.parser.JavaMethodTreeParser;
import br.com.javaparser.methodparser.line.processor.AllEntriesDataProcessor;
import br.com.javaparser.methodparser.line.processor.DataProcessor;
import br.com.javaparser.methodparser.line.visitor.LineObjectVisitor;
import br.com.javaparser.methodparser.line.visitor.impl.SysOutLineObjectVisitor;
import br.com.javaparser.methodparser.strategy.FilterContext;

import java.io.IOException;
import java.nio.file.Path;

public class RunSysOut implements ParserRun {

    @Override
    public void run(Path inputFile, FilterContext filterContext) throws IOException {
        JavaMethodTreeParser javaMethodTreeParser = setupBaseJavaMethodTreeParser();
        DataProcessor dataProcessor = new AllEntriesDataProcessor();
        javaMethodTreeParser.loadParseFile(inputFile, dataProcessor);
        javaMethodTreeParser.visit(buildSysOutLineObjectVisitor(), filterContext);
    }

    public static JavaMethodTreeParser setupBaseJavaMethodTreeParser() {
        JavaMethodTreeParser javaMethodTreeParser = new JavaMethodTreeParser();
        javaMethodTreeParser.addAlternateClassImplNameFormat("%sImpl");
        javaMethodTreeParser.addAlternateClassImplNameFormat("I%s");
        javaMethodTreeParser.debugEnabled(false);

        return javaMethodTreeParser;
    }

    public static LineObjectVisitor buildSysOutLineObjectVisitor() {
        return SysOutLineObjectVisitor.builder()
                .addToIgnoreDestClass("java.")
                .addToIgnoreDestClass("org.slf4j")
                .addToIgnoreDestClass("org.apache.commons")
                .addToIgnoreDestClass("org.springframework.jdbc.core")
                .addToIgnoreDestMethod("java.")
                .addToIgnoreAnnotations("java.lang.Deprecated")
                .addToIgnoreAnnotations("org.springframework.transaction.annotation.Transactional")
                .addToIgnoreAnnotations("javax.persistence.Entity")
                .addToIgnoreAnnotations("org.hibernate.annotations.DynamicInsert")
                .addToIgnoreAnnotations("org.hibernate.annotations.DynamicUpdate")
                .addToIgnoreAnnotations("br.com.bradesco.next.common.annotation.PrimaryKey")
                .addToIgnoreAnnotations("com.fasterxml.jackson.annotation.JsonIgnoreProperties")
                .addToIgnoreAnnotations("javax.validation.constraints")
                .addToIgnoreAnnotations("javax.persistence.ManyToOne")
                .addToIgnoreAnnotations("javax.persistence.Convert")
                .addToIgnoreAnnotations("javax.persistence.Id")
                .addToIgnoreAnnotations("org.springframework.web.bind.annotation.CrossOrigin")
                .addToIgnoreAnnotations("org.springframework.validation.annotation.Validated")
                .addToIgnoreAnnotations("org.springframework.web.bind.annotation.ResponseStatus")
                .build();
    }
}
