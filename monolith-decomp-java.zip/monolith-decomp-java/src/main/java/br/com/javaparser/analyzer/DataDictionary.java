package br.com.javaparser.analyzer;

public class DataDictionary {
	
	private String className;
	private String methodName;
	private String table;
	private String methodNameInClass;
	
	public DataDictionary(String className, String methodName, String table, String methodNameInClass) {
		super();
		this.className = className;
		this.methodName = methodName;
		this.table = table;
		this.methodNameInClass =methodNameInClass;
	}
	
	
	
	public String getMethodNameInClass() {
		return methodNameInClass;
	}

	public String getClassName() {
		return className;
	}

	public String getMethodName() {
		return methodName;
	}



	public String getTable() {
		return table;
	}
	

	public void setTable(String table) {
		this.table = table;
	}



	@Override
	public String toString() {
		return "DataDictionary [className=" + className + ", methodName=" + methodName + ", table=" + table
				+ ", methodNameInClass=" + methodNameInClass + "]";
	}



}
