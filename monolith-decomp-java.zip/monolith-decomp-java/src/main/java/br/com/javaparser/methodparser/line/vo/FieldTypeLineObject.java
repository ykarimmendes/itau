package br.com.javaparser.methodparser.line.vo;

import lombok.Data;

@Data
public class FieldTypeLineObject extends LineObject {
    private String field;
    private String type;

    public FieldTypeLineObject(String originType, String originClass, String field, String type) {
        super(originType, originClass);
        this.field = field;
        this.type = type;
    }
}
