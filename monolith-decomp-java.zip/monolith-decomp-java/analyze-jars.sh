#!/bin/bash
#############################################################################################################

#############################################################################################################
java_parser_jar_path="../../java-parser/target"
java_analysis_cmd="java -cp ${java_parser_jar_path}/java-parser-1.0-SNAPSHOT.jar br.com.javaparser.analyzer.JCallGraph"
java_parser_cmd="java -cp ${java_parser_jar_path}/java-parser-1.0-SNAPSHOT.jar br.com.javaparser.methodparser.ParserMain"
#############################################################################################################

#############################################################################################################
get_simple_name() {
	echo "${1}" | awk -F"-" '{print $1 "-" $2 "-" $3}'
}
#############################################################################################################

#############################################################################################################
remote_file_ext() {
	echo "${1}" | cut -f1 -d"."
}
#############################################################################################################

#############################################################################################################
generate_concat_analysis() {
	nextplatform_jars_path="${1}"
	nextplatform_version="${2}"
	analisys_output_file="${3}"

	cp /dev/null "${analisys_output_file}"
	
	echo "All analysis will be in: [${analisys_output_file}]..."
	find ${nextplatform_jars_path} -name "*${nextplatform_version}.jar" | while read jarFile
	do
		echo "Analyzing file: [${jarFile}]"
		${java_analysis_cmd} "${jarFile}" >> "${analisys_output_file}"
	done
}
#############################################################################################################

#############################################################################################################
runType="${1:-1}"
nextplatform_jars_path="${2}"
nextplatform_version="${3}"
analisys_output_dir="${4}"
output_file_base_name="${5:-nextbank}"

base_output_file="${analisys_output_dir}/${output_file_base_name}-${nextplatform_version}"
analisys_output_file="${base_output_file}-analysis.txt"
callgraph_output_file="${base_output_file}-callgraph.txt"

generate_concat_analysis "${nextplatform_jars_path}" "${nextplatform_version}" "${analisys_output_file}"

echo "Printing callgraph to: [${callgraph_output_file}]"
${java_parser_cmd} "${runType}" "${analisys_output_file}" > "${callgraph_output_file}"
