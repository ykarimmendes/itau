# Java Method Three Parser Utility

## Usage:

This is a two step process and it comprises of the following sequence of commands. 

First you must run the **Maven** task to package the JAR. In the following example, it was generated at the root project path\target directory

### Generate the raw CallGraph
```
java -cp .\target\java-parser-1.0-SNAPSHOT.jar br.com.javaparser.analyzer.JCallGraph C:\repositories\java-course\java-course.jar >> C:\temp\analysis-javacourse.txt
```

### Generate the Method Parser based on raw CallGraph
```
java -cp .\target\java-parser-1.0-SNAPSHOT.jar br.com.javaparser.methodparser.ParserMain 1 C:\temp\analysis-javacourse.txt > C:\temp\callgraph-javacourse.txt
```